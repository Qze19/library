import React, { useState, useEffect, useCallback } from 'react';
import ChatPanel from './components/ChatPanel';
import ConfigDashboard from './components/ConfigDashboard';
import AgentStatusPanel from './components/AgentStatusPanel';
import NavigationPanel from './components/NavigationPanel';
import { orchestrate, getAgentStatus } from './lib/orchestrator';
import type { AgentResponse } from './lib/orchestrator';

type View = 'chat' | 'nav' | 'config';
 
function App() {
  const [view, setView] = useState<View>('chat');
  const [status, setStatus] = useState<ReturnType<typeof getAgentStatus> | null>(null);
  const [userId] = useState(() => `user_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`);
 
  useEffect(() => {
    setStatus(getAgentStatus());
  }, []);
 
  const handleSend = useCallback(
    async (msg: string): Promise<AgentResponse> => {
      return orchestrate(msg, userId);
    },
    [userId],
  );
 
  return (
    <div className="app-container">
      <aside className="sidebar">
        <div className="sidebar-brand">
          <h1>📖 智图灵伴</h1>
          <p className="brand-sub">高校图书馆AI智能体</p>
        </div>
 
        <nav className="sidebar-nav">
          <button
            className={`nav-btn ${view === 'chat' ? 'active' : ''}`}
            onClick={() => setView('chat')}
          >
            💬 对话服务
          </button>
          <button
            className={`nav-btn ${view === 'nav' ? 'active' : ''}`}
            onClick={() => setView('nav')}
          >
            🗺️ 馆内导航
          </button>
          <button
            className={`nav-btn ${view === 'config' ? 'active' : ''}`}
            onClick={() => setView('config')}
          >
            ⚙️ 配置管理
          </button>
        </nav>
 
        <AgentStatusPanel status={status} />
 
        <div className="sidebar-footer">
          <p>v{status?.version ?? '1.0.0'}</p>
          <p className="footer-hint">Powered by 超星</p>
        </div>
      </aside>
 
      <main className="main-content">
        {view === 'chat' ? <ChatPanel onSend={handleSend} /> : view === 'nav' ? <NavigationPanel /> : <ConfigDashboard />}
      </main>
    </div>
  );
}
 
export default App;