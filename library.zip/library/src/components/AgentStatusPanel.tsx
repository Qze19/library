import React from 'react';
 
interface Props {
  status: ReturnType<typeof import('../lib/orchestrator').getAgentStatus> | null;
}
 
const AgentStatusPanel: React.FC<Props> = ({ status }) => {
  if (!status) return null;
 
  return (
    <div className="status-panel">
      <h3>🤖 {status.name} v{status.version}</h3>
      <div className="status-grid">
        <div className="status-item">
          <span className="status-label">知识库匹配阈值</span>
          <span className="status-value highlight">{(status.knowledgeMatchThreshold * 100).toFixed(0)}%</span>
        </div>
        <div className="status-item">
          <span className="status-label">长期记忆</span>
          <span className={`status-value ${status.enableLongTermMemory ? 'on' : 'off'}`}>
            {status.enableLongTermMemory ? '✅ 已开启' : '❌ 已关闭'}
          </span>
        </div>
        <div className="status-item">
          <span className="status-label">联网搜索</span>
          <span className={`status-value ${status.enableWebSearch ? 'on' : 'off'}`}>
            {status.enableWebSearch ? '✅ 已开启' : '❌ 已关闭'}
          </span>
        </div>
      </div>
 
      <h4>📚 知识库</h4>
      <ul className="kb-list">
        {status.knowledgeBases.map((kb) => (
          <li key={kb.name}>
            <span className="kb-name">{kb.name}</span>
            <span className="kb-count">{kb.entries}条</span>
          </li>
        ))}
      </ul>
 
      <h4>⚡ 工作流</h4>
      <ul className="wf-list">
        {status.workflows.map((wf) => (
          <li key={wf}>{wf}</li>
        ))}
      </ul>
 
      <h4>🛠️ 技能</h4>
      <ul className="skill-list">
        {status.skills.map((s) => (
          <li key={s.id} className={s.enabled ? 'enabled' : 'disabled'}>
            {s.name} {s.enabled ? '✅' : '⏸️'}
          </li>
        ))}
      </ul>
    </div>
  );
};
 
export default AgentStatusPanel;