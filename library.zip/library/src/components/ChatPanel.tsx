import React, { useState, useRef, useEffect } from 'react';
import type { AgentResponse } from '../lib/orchestrator';
import { INTENT_LABELS } from '../config/systemPrompt';
import type { IntentType } from '../config/systemPrompt';

interface Props {
  onSend: (msg: string) => Promise<AgentResponse>;
}

interface ChatMessage {
  role: 'user' | 'agent';
  content: string;
  meta?: {
    intent?: string;
    kbScore?: number;
    fallbackUsed?: boolean;
    workflow?: string | null;
    skills?: string[];
    webSearchUsed?: boolean;
  };
}

const AGENT_WELCOME = `【智图灵伴】您好！我是高校图书馆AI智能助手。请问有什么可以帮您的？

您可以咨询：
📚 读者服务（借阅、续借、预约等）
⚠️ 借阅异常诊断
📊 馆务管理（分类、索书号等）
🏛️ 空间与展馆（自习室、研讨间、展览等）`;

/** 将意图标识符映射为中文标签 */
function intentLabel(intent?: string): string {
  if (!intent || intent === 'unknown') return '';
  return INTENT_LABELS[intent as IntentType] ?? (intent === 'academic_inquiry' ? '🎓 学术问询' : intent);
}

/** 轻量 Markdown 渲染：逐行处理 **加粗**（React 默认转义，无 XSS 风险） */
function renderMarkdown(text: string): React.ReactNode[] {
  const lines = text.split('\n');
  return lines.map((line, lineIdx) => {
    const parts = line.split('**');
    return (
      <div key={lineIdx}>
        {parts.map((part, i) =>
          i % 2 === 1 ? <strong key={i}>{part}</strong> : <React.Fragment key={i}>{part}</React.Fragment>,
        )}
      </div>
    );
  });
}

const ChatPanel: React.FC<Props> = ({ onSend }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'agent', content: AGENT_WELCOME },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // 新消息到达时自动滚动到底部
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);
 
  const handleSend = async () => {
    const text = input.trim();
    if (!text || loading) return;
 
    setInput('');
    setMessages((prev) => [...prev, { role: 'user', content: text }]);
    setLoading(true);
 
    try {
      const result = await onSend(text);
      setMessages((prev) => [
        ...prev,
        {
          role: 'agent',
          content: result.message,
          meta: {
            intent: result.intent,
            kbScore: result.kbScore,
            fallbackUsed: result.fallbackUsed,
            workflow: result.workflowTriggered,
            skills: result.skillsUsed,
            webSearchUsed: result.webSearchUsed,
          },
        },
      ]);
    } catch {
      setMessages((prev) => [
        ...prev,
        { role: 'agent', content: '【智图灵伴】抱歉，系统出现了临时问题，请稍后再试。' },
      ]);
    } finally {
      setLoading(false);
    }
  };
 
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };
 
  return (
    <div className="chat-panel">
      <div className="chat-header">
        <h2>💬 智图灵伴 · 对话</h2>
        <div className="chat-header-right">
          <span className="chat-subtitle">高校图书馆AI智能助手</span>
          <button
            className="clear-btn"
            onClick={() => setMessages([{ role: 'agent', content: AGENT_WELCOME }])}
            disabled={loading || messages.length <= 1}
            title="清空对话记录"
          >
            🗑️ 清空
          </button>
        </div>
      </div>

      <div className="chat-messages">
        {messages.map((msg, i) => (
          <div key={i} className={`chat-message ${msg.role}`}>
            <div className="message-avatar">{msg.role === 'agent' ? '🤖' : '👤'}</div>
            <div className="message-body">
              <div className="message-content">{renderMarkdown(msg.content)}</div>
              {msg.meta && msg.meta.intent !== 'unknown' && (
                <div className="message-meta">
                  {msg.meta.intent && <span className="meta-tag">意图：{intentLabel(msg.meta.intent)}</span>}
                  {msg.meta.kbScore !== undefined && msg.meta.kbScore > 0 && (
                    <span className="meta-tag">匹配度：{(msg.meta.kbScore * 100).toFixed(0)}%</span>
                  )}
                  {msg.meta.fallbackUsed && <span className="meta-tag warn">兜底回复</span>}
                  {msg.meta.workflow && <span className="meta-tag">工作流：{msg.meta.workflow}</span>}
                  {msg.meta.skills && msg.meta.skills.length > 0 && (
                    <span className="meta-tag">技能：{msg.meta.skills.join(', ')}</span>
                  )}
                  {msg.meta.webSearchUsed && <span className="meta-tag info">🌐 已联网补充</span>}
                </div>
              )}
            </div>
          </div>
        ))}
        {loading && (
          <div className="chat-message agent">
            <div className="message-avatar">🤖</div>
            <div className="message-body">
              <div className="typing-indicator">
                <span></span><span></span><span></span>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
 
      <div className="chat-input-area">
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="请输入您的问题，例如：我续借失败了怎么办？"
          rows={2}
          disabled={loading}
        />
        <button onClick={handleSend} disabled={loading || !input.trim()}>
          {loading ? '思考中…' : '发送'}
        </button>
      </div>
    </div>
  );
};
 
export default ChatPanel;