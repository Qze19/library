import React from 'react';
import type { IntentType } from '../config/systemPrompt';
import { INTENT_LABELS, INTENT_KEYWORDS } from '../config/systemPrompt';
import { SKILL_CONFIGS } from '../config/skills';
import { AGENT_CONFIG } from '../lib/orchestrator';
import {
  SPACE_KNOWLEDGE_BASE,
  TIME_RULES,
  FLOOR_MAP,
  NAV_QA_GUIDE,
  BORROWING_DIAGNOSTIC_KB,
  BOOK_CLASSIFICATION_KB,
  MISSING_RESOURCES_KB,
  ELECTRONIC_RESOURCES_KB,
  PHYSICAL_BOOKS_KB,
  EBOOKS_KB,
  BORROWING_DIAGNOSTIC_WORKFLOW,
  LIBRARY_MANAGEMENT_WORKFLOW,
  SPACE_NAVIGATION_WORKFLOW,
  ACADEMIC_INQUIRY_WORKFLOW,
} from '../config';
 
const ConfigDashboard: React.FC = () => {
  return (
    <div className="config-dashboard">
      <h2>⚙️ 智能体配置</h2>
 
      {/* 系统提示词概览 */}
      <section className="config-section">
        <h3>📋 系统提示词</h3>
        <div className="config-card">
          <div className="config-row">
            <span className="config-key">智能体名称</span>
            <span className="config-value">{AGENT_CONFIG.name}</span>
          </div>
          <div className="config-row">
            <span className="config-key">版本</span>
            <span className="config-value">{AGENT_CONFIG.version}</span>
          </div>
          <div className="config-row">
            <span className="config-key">知识库匹配阈值</span>
            <span className="config-value highlight">{(AGENT_CONFIG.knowledgeMatchThreshold * 100).toFixed(0)}%</span>
          </div>
          <div className="config-row">
            <span className="config-key">长期记忆</span>
            <span className="config-value on">{AGENT_CONFIG.enableLongTermMemory ? '✅ 已开启' : '❌ 已关闭'}</span>
          </div>
          <div className="config-row">
            <span className="config-key">记忆保留天数</span>
            <span className="config-value">{AGENT_CONFIG.memoryRetentionDays}天</span>
          </div>
          <div className="config-row">
            <span className="config-key">联网搜索</span>
            <span className="config-value on">{AGENT_CONFIG.enableWebSearch ? '✅ 已开启' : '❌ 已关闭'}</span>
          </div>
          <div className="config-row">
            <span className="config-key">未知回复兜底</span>
            <span className="config-value on">{AGENT_CONFIG.enableFallback ? '✅ 已开启' : '❌ 已关闭'}</span>
          </div>
        </div>
      </section>
 
      {/* 意图分流 */}
      <section className="config-section">
        <h3>🔀 意图分流逻辑</h3>
        {Object.entries(INTENT_LABELS).map(([key, label]) => (
          <div key={key} className="config-card intent-card">
            <h4>{label}</h4>
            <p className="intent-keywords">
              <strong>触发关键词：</strong>
              {INTENT_KEYWORDS[key as IntentType].slice(0, 8).join('、')}
              {INTENT_KEYWORDS[key as IntentType].length > 8 ? '…' : ''}
            </p>
          </div>
        ))}
      </section>
 
      {/* 知识库 — 统计数字从真实数据计算 */}
      <section className="config-section">
        <h3>📚 结构化知识库（5个）</h3>
        <div className="config-card">
          <div className="kb-item">
            <strong>1. 空间与导航库</strong> — {SPACE_KNOWLEDGE_BASE.length}个功能点位 + {NAV_QA_GUIDE.length}条导航问答 + {TIME_RULES.length}套时间规则 + {Object.keys(FLOOR_MAP).length}层楼层导航
          </div>
          <div className="kb-item">
            <strong>2. 借阅异常诊断库</strong> — {BORROWING_DIAGNOSTIC_KB.length}个诊断条目，覆盖借阅/归还/续借/预约/罚款/账户异常
          </div>
          <div className="kb-item">
            <strong>3. 图书分类索引库</strong> — {BOOK_CLASSIFICATION_KB.length}个中图法大类 + 索书号规则
          </div>
          <div className="kb-item">
            <strong>4. 资源缺失/目录库</strong> — {MISSING_RESOURCES_KB.length}条缺失资源 + {ELECTRONIC_RESOURCES_KB.length}个电子资源
          </div>
          <div className="kb-item">
            <strong>5. 馆藏资源库（新增）</strong> — {PHYSICAL_BOOKS_KB.length}本纸质书（含位置/索书号/状态）+ {EBOOKS_KB.length}本电子书（含跳转URL）
          </div>
        </div>
      </section>

      {/* 工作流 — 步骤数从真实数据计算 */}
      <section className="config-section">
        <h3>⚡ 工作流（4个）</h3>
        <div className="config-card">
          <div className="wf-item">
            <strong>{BORROWING_DIAGNOSTIC_WORKFLOW.name}</strong>
            <p className="wf-desc">触发意图：borrowing_exception | 步骤数：{BORROWING_DIAGNOSTIC_WORKFLOW.steps.length}步（含升级和确认）</p>
          </div>
          <div className="wf-item">
            <strong>{ACADEMIC_INQUIRY_WORKFLOW.name}（新增）</strong>
            <p className="wf-desc">触发意图：academic_inquiry | 阶段数：{ACADEMIC_INQUIRY_WORKFLOW.stages.length}阶段 — {ACADEMIC_INQUIRY_WORKFLOW.stages.map((s) => s.name).join('→')}</p>
          </div>
          <div className="wf-item">
            <strong>{LIBRARY_MANAGEMENT_WORKFLOW.name}</strong>
            <p className="wf-desc">触发意图：library_management | 步骤数：{LIBRARY_MANAGEMENT_WORKFLOW.steps.length}步</p>
          </div>
          <div className="wf-item">
            <strong>{SPACE_NAVIGATION_WORKFLOW.name}</strong>
            <p className="wf-desc">触发意图：space_exhibition | 步骤数：{SPACE_NAVIGATION_WORKFLOW.steps.length}步</p>
          </div>
        </div>
      </section>
 
      {/* 技能 */}
      <section className="config-section">
        <h3>🛠️ 技能设置</h3>
        <div className="config-card">
          {SKILL_CONFIGS.map((skill) => (
            <div key={skill.id} className="skill-item">
              <div className="skill-header">
                <strong>{skill.name}</strong>
                <span className={`skill-status ${skill.enabled ? 'on' : 'off'}`}>
                  {skill.enabled ? '✅ 已启用' : '⏸️ 可选'}
                </span>
              </div>
              <p className="skill-desc">{skill.description}</p>
              <div className="skill-config">
                {Object.entries(skill.config).map(([k, v]) => (
                  <span key={k} className="skill-config-tag">
                    {k}: {typeof v === 'object' ? JSON.stringify(v) : String(v)}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>
 
      {/* 输出格式规范 */}
      <section className="config-section">
        <h3>📝 输出格式规范</h3>
        <div className="config-card">
          <ul className="format-rules">
            <li>每条回复以【智图灵伴】开头</li>
            <li>包含 📋 问题识别（意图分类标签）</li>
            <li>核心回答使用清晰段落</li>
            <li>附带 💡 相关提示和 📞 进一步帮助通道</li>
            <li>异常诊断采用"症状→原因→解决方案"结构</li>
            <li>空间相关给出具体楼层和方位</li>
          </ul>
        </div>
      </section>
    </div>
  );
};
 
export default ConfigDashboard;