import React, { useState, useMemo } from 'react';
import {
  SPACE_KNOWLEDGE_BASE,
  ENTRANCES,
  NAV_QA_GUIDE,
  findSpaces,
  type SpaceInfo,
} from '../config';

const FLOORS = [1, 2, 3, 4] as const;

const FLOOR_THEME: Record<number, { aLabel: string; bLabel: string }> = {
  1: { aLabel: '馆员工作区', bLabel: '休闲文化区' },
  2: { aLabel: '综合服务区', bLabel: '学习中心区' },
  3: { aLabel: '综合服务区', bLabel: '学习中心区' },
  4: { aLabel: '综合服务区', bLabel: '学习中心区' },
};

const CATEGORY_META: Record<SpaceInfo['category'], { icon: string; label: string }> = {
  reading: { icon: '📖', label: '阅览' },
  study: { icon: '✏️', label: '学习' },
  discussion: { icon: '💬', label: '研修' },
  exhibition: { icon: '🖼️', label: '展览' },
  multimedia: { icon: '🎧', label: '多媒体' },
  maker: { icon: '🔧', label: '创客' },
  relaxation: { icon: '☕', label: '休闲' },
  service: { icon: '🛎️', label: '服务' },
  collection: { icon: '📚', label: '藏书' },
  staff: { icon: '🏢', label: '业务' },
};

function shortName(name: string): string {
  // 地图上使用短名称，去掉楼层前缀等重复信息
  return name
    .replace(/（[^）]*）/g, '')
    .replace(/一层|二层|三层|四层/g, '')
    .trim();
}

const NavigationPanel: React.FC = () => {
  const [floor, setFloor] = useState<number>(2);
  const [query, setQuery] = useState('');
  const [highlightId, setHighlightId] = useState<string | null>(null);

  // 搜索结果：跨楼层查找点位
  const searchResults = useMemo(() => {
    const kw = query.trim();
    if (!kw) return [];
    return findSpaces(kw).slice(0, 8);
  }, [query]);

  const spacesOnFloor = useMemo(
    () => SPACE_KNOWLEDGE_BASE.filter((s) => s.floor === floor),
    [floor],
  );
  const zoneA = spacesOnFloor.filter((s) => s.zone === 'A区');
  const zoneB = spacesOnFloor.filter((s) => s.zone === 'B区');

  const entrancesOnFloor = ENTRANCES.filter((e) => e.floor === floor);

  const jumpToSpace = (space: SpaceInfo) => {
    setFloor(space.floor);
    setHighlightId(space.id);
    setQuery('');
  };

  const renderSpaceChip = (s: SpaceInfo) => {
    const meta = CATEGORY_META[s.category];
    const highlighted = highlightId === s.id;
    return (
      <button
        key={s.id}
        className={`map-chip cat-${s.category} ${highlighted ? 'highlighted' : ''} ${s.readerFavorite ? 'favorite' : ''}`}
        title={`${s.description}${s.position ? `（${s.position}）` : ''}`}
        onClick={() => setHighlightId(highlighted ? null : s.id)}
      >
        <span className="chip-icon">{meta.icon}</span>
        <span className="chip-name">{shortName(s.name)}</span>
        {s.readerFavorite && <span className="chip-star">★</span>}
      </button>
    );
  };

  const selected = highlightId
    ? SPACE_KNOWLEDGE_BASE.find((s) => s.id === highlightId) ?? null
    : null;

  return (
    <div className="nav-panel">
      <div className="nav-header">
        <h2>🗺️ 馆内导航</h2>
        <span className="nav-subtitle">武汉职业技术大学图书馆 · 共四层（每层分 A区 / B区）· 开放 8:00—21:00</span>
      </div>

      {/* 点位搜索 */}
      <div className="nav-search">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="搜索馆内点位，如：安静阅览区、期刊、服务台、书库…"
        />
        {query.trim() && (
          <div className="nav-search-results">
            {searchResults.length === 0 && <div className="no-result">没有找到相关点位，换个关键词试试</div>}
            {searchResults.map((s) => (
              <button key={s.id} className="search-hit" onClick={() => jumpToSpace(s)}>
                <span className="hit-name">
                  {CATEGORY_META[s.category].icon} {s.name}
                </span>
                <span className="hit-loc">
                  {s.floor}层{s.zone}
                  {s.position ? ` · ${s.position}` : ''}
                </span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* 楼层切换 */}
      <div className="floor-tabs">
        {FLOORS.map((f) => (
          <button
            key={f}
            className={`floor-tab ${floor === f ? 'active' : ''}`}
            onClick={() => {
              setFloor(f);
              setHighlightId(null);
            }}
          >
            {f}F
          </button>
        ))}
      </div>

      {/* 楼层平面图 */}
      <div className="floor-map">
        <div className="map-zone zone-a">
          <div className="zone-label">A区 · {FLOOR_THEME[floor].aLabel}</div>
          <div className="zone-chips">{zoneA.map(renderSpaceChip)}</div>
        </div>
        <div className="map-corridor">
          <span>通</span>
          <span>道</span>
        </div>
        <div className="map-zone zone-b">
          <div className="zone-label">B区 · {FLOOR_THEME[floor].bLabel}</div>
          <div className="zone-chips">{zoneB.map(renderSpaceChip)}</div>
        </div>
        {entrancesOnFloor.length > 0 && (
          <div className="map-entrances">
            {entrancesOnFloor.map((e) => (
              <span key={e.name} className="entrance-tag">
                🚪 {e.name}（{e.note}）
              </span>
            ))}
          </div>
        )}
      </div>

      {/* 选中的点位详情 */}
      {selected && (
        <div className="space-detail">
          <div className="detail-title">
            {CATEGORY_META[selected.category].icon} {selected.name}
            <span className="detail-loc">
              📍 {selected.floor}层 {selected.zone}
              {selected.position ? ` · ${selected.position}` : ''}
            </span>
          </div>
          <p>{selected.description}</p>
          {selected.facilities.length > 0 && <p className="detail-meta">设施：{selected.facilities.join('、')}</p>}
          {selected.rules.length > 0 && <p className="detail-meta">规则：{selected.rules.join('；')}</p>}
        </div>
      )}

      {/* 高频导航问答 */}
      <div className="nav-qa">
        <h3>❓ 高频导航问题</h3>
        <div className="qa-list">
          {NAV_QA_GUIDE.map((qa) => (
            <details key={qa.id} className="qa-item">
              <summary>{qa.question}</summary>
              <p>{qa.answer}</p>
            </details>
          ))}
        </div>
      </div>
    </div>
  );
};

export default NavigationPanel;
