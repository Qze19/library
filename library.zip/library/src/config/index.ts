export { SYSTEM_PROMPT, INTENT_LABELS, INTENT_KEYWORDS, INTENT_PRIORITY } from './systemPrompt';
export type { IntentType, IntentMatch } from './systemPrompt';
 
export { SPACE_KNOWLEDGE_BASE, TIME_RULES, FLOOR_MAP, ENTRANCES, NAV_QA_GUIDE, findSpaces } from './knowledgeBase_spaces';
export type { SpaceInfo, TimeRule, NavQA } from './knowledgeBase_spaces';
 
export { BORROWING_DIAGNOSTIC_KB } from './knowledgeBase_diagnostics';
export type { DiagnosticEntry } from './knowledgeBase_diagnostics';
 
export { BOOK_CLASSIFICATION_KB, CALL_NUMBER_RULES } from './knowledgeBase_classification';
export type { ClassificationEntry } from './knowledgeBase_classification';
 
export { MISSING_RESOURCES_KB, ELECTRONIC_RESOURCES_KB } from './knowledgeBase_resources';
export type { MissingResource, ElectronicResource } from './knowledgeBase_resources';
 
export {
  PHYSICAL_BOOKS_KB,
  EBOOKS_KB,
  PHYSICAL_EBOOK_MAP,
} from './knowledgeBase_holdings';
export type { PhysicalBook, EBookResource, RelatedPhysicalBook } from './knowledgeBase_holdings';
 
export { BORROWING_DIAGNOSTIC_WORKFLOW } from './workflow_diagnostic';
export { LIBRARY_MANAGEMENT_WORKFLOW } from './workflow_management';
export { SPACE_NAVIGATION_WORKFLOW } from './workflow_navigation';
export {
  ACADEMIC_INQUIRY_WORKFLOW,
  parseAcademicIntent,
  synthesizeAcademicResponse,
} from './workflow_academic';
export type {
  ParsedAcademicIntent,
  HoldingsMatchItem,
  WebSearchSupplement,
  AcademicWorkflowStage,
  AcademicWorkflow,
} from './workflow_academic';
 
export { SKILL_CONFIGS, RESOURCE_RECOMMEND_TAGS } from './skills';
export type { SkillConfig, ResourceRecommendTag } from './skills';