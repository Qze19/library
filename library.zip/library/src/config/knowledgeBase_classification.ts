/**
 * 知识库三：图书分类索引库
 * 涵盖中图法分类体系、索书号规则和学科映射
 */
 
export interface ClassificationEntry {
  code: string;
  className: string;
  description: string;
  subClasses: { code: string; name: string; description: string }[];
  location: string;
  keywords: string[];
}
 
export const BOOK_CLASSIFICATION_KB: ClassificationEntry[] = [
  {
    code: 'A',
    className: '马克思主义、列宁主义、毛泽东思想、邓小平理论',
    description: '马恩列斯毛邓著作、生平和传记，以及相关学习和研究资料',
    subClasses: [
      { code: 'A1', name: '马克思、恩格斯著作', description: '全集、选集、单行著作' },
      { code: 'A2', name: '列宁著作', description: '全集、选集、单行著作' },
      { code: 'A4', name: '毛泽东著作', description: '全集、选集、单行著作' },
      { code: 'A8', name: '马克思主义研究', description: '学习和研究资料' },
    ],
    location: '四层图书借阅区 A类',
    keywords: ['马克思主义', '列宁', '毛泽东', '邓小平', '政治经济学'],
  },
  {
    code: 'B',
    className: '哲学、宗教',
    description: '哲学理论、世界哲学、中国哲学、逻辑学、伦理学、美学、心理学、宗教',
    subClasses: [
      { code: 'B0', name: '哲学理论', description: '马克思主义哲学、哲学基本问题' },
      { code: 'B2', name: '中国哲学', description: '先秦至现代中国哲学' },
      { code: 'B5', name: '欧洲哲学', description: '古希腊至现代西方哲学' },
      { code: 'B84', name: '心理学', description: '普通心理学、应用心理学' },
    ],
    location: '四层图书借阅区 B类',
    keywords: ['哲学', '心理学', '逻辑', '伦理', '美学', '宗教'],
  },
  {
    code: 'C',
    className: '社会科学总论',
    description: '统计学、社会学、人口学、管理学、民族学、人才学',
    subClasses: [
      { code: 'C8', name: '统计学', description: '统计方法、统计软件' },
      { code: 'C91', name: '社会学', description: '社会结构、社会关系' },
      { code: 'C93', name: '管理学', description: '管理理论、管理方法' },
    ],
    location: '四层图书借阅区 C类',
    keywords: ['社会学', '统计', '管理', '人口', '人才'],
  },
  {
    code: 'D',
    className: '政治、法律',
    description: '政治理论、中国政治、各国政治、外交、法律',
    subClasses: [
      { code: 'D0', name: '政治理论', description: '政治学基础理论' },
      { code: 'D6', name: '中国政治', description: '中国政府、政策' },
      { code: 'D9', name: '法律', description: '法学理论、各部门法' },
    ],
    location: '四层图书借阅区 D类',
    keywords: ['政治', '法律', '宪法', '民法典', '行政法', '国际法'],
  },
  {
    code: 'E',
    className: '军事',
    description: '军事理论、世界军事、中国军事、战略战术、军事技术',
    subClasses: [
      { code: 'E0', name: '军事理论', description: '战争理论、军事哲学' },
      { code: 'E2', name: '中国军事', description: '中国军队、国防' },
    ],
    location: '四层图书借阅区 E类',
    keywords: ['军事', '战争', '国防', '战略', '武器'],
  },
  {
    code: 'F',
    className: '经济',
    description: '经济学、经济管理、各部门经济、财政金融',
    subClasses: [
      { code: 'F0', name: '经济学', description: '政治经济学、宏观/微观经济学' },
      { code: 'F2', name: '经济管理', description: '经济计划与管理' },
      { code: 'F8', name: '财政金融', description: '财政、货币、银行' },
    ],
    location: '四层图书借阅区 F类',
    keywords: ['经济', '金融', '财政', '银行', '证券', '贸易', '会计'],
  },
  {
    code: 'G',
    className: '文化、科学、教育、体育',
    description: '文化理论、信息与知识传播、科学教育、高等教育、体育',
    subClasses: [
      { code: 'G2', name: '信息与知识传播', description: '新闻、出版、图书馆学、情报学' },
      { code: 'G4', name: '教育', description: '教育学、教学理论' },
      { code: 'G6', name: '高等教育', description: '大学教育、研究生教育' },
      { code: 'G8', name: '体育', description: '体育理论、各项运动' },
    ],
    location: '四层图书借阅区 G类',
    keywords: ['教育', '图书馆', '新闻', '出版', '体育', '情报学'],
  },
  {
    code: 'H',
    className: '语言、文字',
    description: '语言学、汉语、外语、常用外国语',
    subClasses: [
      { code: 'H0', name: '语言学', description: '语言理论、语言哲学' },
      { code: 'H1', name: '汉语', description: '古代汉语、现代汉语' },
      { code: 'H31', name: '英语', description: '英语学习、英语考试' },
    ],
    location: '四层图书借阅区 H类',
    keywords: ['语言', '汉语', '英语', '日语', '法语', '翻译', '四六级', '雅思'],
  },
  {
    code: 'I',
    className: '文学',
    description: '文学理论、世界文学、中国文学、各国文学',
    subClasses: [
      { code: 'I2', name: '中国文学', description: '诗歌、小说、散文、戏剧' },
      { code: 'I5', name: '欧洲文学', description: '英国、法国、德国等文学' },
    ],
    location: '四层图书借阅区 I类',
    keywords: ['文学', '小说', '诗歌', '散文', '戏剧', '名著', '经典'],
  },
  {
    code: 'J',
    className: '艺术',
    description: '艺术理论、绘画、书法、雕塑、摄影、音乐、舞蹈、电影',
    subClasses: [
      { code: 'J2', name: '绘画', description: '国画、油画、版画' },
      { code: 'J6', name: '音乐', description: '音乐理论、器乐、声乐' },
      { code: 'J9', name: '电影电视', description: '电影艺术、影视制作' },
    ],
    location: '五层图书借阅区 J类',
    keywords: ['艺术', '绘画', '书法', '摄影', '音乐', '电影', '设计'],
  },
  {
    code: 'K',
    className: '历史、地理',
    description: '史学理论、世界史、中国史、传记、文物考古、地理',
    subClasses: [
      { code: 'K2', name: '中国史', description: '古代至现代中国历史' },
      { code: 'K9', name: '地理', description: '世界地理、中国地理' },
    ],
    location: '四层图书借阅区 K类',
    keywords: ['历史', '地理', '传记', '考古', '世界史', '中国史'],
  },
  {
    code: 'N',
    className: '自然科学总论',
    description: '自然科学理论与方法、系统科学',
    subClasses: [
      { code: 'N0', name: '自然科学理论', description: '科学哲学、科学方法论' },
      { code: 'N94', name: '系统科学', description: '系统论、控制论、信息论' },
    ],
    location: '五层图书借阅区 N类',
    keywords: ['自然科学', '系统科学', '控制论', '信息论'],
  },
  {
    code: 'O',
    className: '数理科学和化学',
    description: '数学、力学、物理学、化学、晶体学',
    subClasses: [
      { code: 'O1', name: '数学', description: '高等数学、代数、几何、概率论' },
      { code: 'O4', name: '物理学', description: '理论物理、应用物理' },
      { code: 'O6', name: '化学', description: '无机化学、有机化学' },
    ],
    location: '五层图书借阅区 O类',
    keywords: ['数学', '物理', '化学', '力学', '高等数学', '线性代数'],
  },
  {
    code: 'P',
    className: '天文学、地球科学',
    description: '天文学、测绘学、地球物理学、地质学',
    subClasses: [
      { code: 'P1', name: '天文学', description: '天体测量、天体物理' },
      { code: 'P5', name: '地质学', description: '矿物学、岩石学' },
    ],
    location: '五层图书借阅区 P类',
    keywords: ['天文', '地质', '气象', '海洋', '测绘'],
  },
  {
    code: 'Q',
    className: '生物科学',
    description: '普通生物学、细胞生物学、遗传学、生物化学、微生物学、植物学、动物学',
    subClasses: [
      { code: 'Q2', name: '细胞生物学', description: '细胞结构、细胞生理' },
      { code: 'Q3', name: '遗传学', description: '基因、遗传变异' },
      { code: 'Q5', name: '生物化学', description: '蛋白质、核酸、酶' },
    ],
    location: '五层图书借阅区 Q类',
    keywords: ['生物', '基因', '细胞', '微生物', '植物', '动物', '遗传'],
  },
  {
    code: 'R',
    className: '医药、卫生',
    description: '预防医学、基础医学、临床医学、药学',
    subClasses: [
      { code: 'R1', name: '预防医学', description: '公共卫生、流行病学' },
      { code: 'R4', name: '临床医学', description: '诊断学、治疗学' },
    ],
    location: '五层图书借阅区 R类',
    keywords: ['医学', '药学', '临床', '护理', '卫生'],
  },
  {
    code: 'S',
    className: '农业科学',
    description: '农业基础科学、农学、植物保护、园艺、林业、畜牧',
    subClasses: [
      { code: 'S5', name: '农作物', description: '粮食作物、经济作物' },
      { code: 'S6', name: '园艺', description: '蔬菜、果树、花卉' },
    ],
    location: '五层图书借阅区 S类',
    keywords: ['农业', '农作物', '园艺', '林业', '畜牧'],
  },
  {
    code: 'T',
    className: '工业技术',
    description: '一般工业技术、矿业、石油、冶金、机械、电工、电子、计算机、自动化',
    subClasses: [
      { code: 'TB', name: '一般工业技术', description: '工程基础科学、材料科学' },
      { code: 'TH', name: '机械、仪表', description: '机械设计、制造' },
      { code: 'TM', name: '电工技术', description: '电气工程、电力系统' },
      { code: 'TN', name: '电子与通信', description: '电子技术、通信工程' },
      { code: 'TP', name: '自动化与计算机', description: '人工智能、软件工程、网络' },
      { code: 'TU', name: '建筑科学', description: '建筑设计、土木工程' },
    ],
    location: '五层图书借阅区 T类',
    keywords: ['计算机', '人工智能', '软件', '机械', '电子', '建筑', '自动化', '编程', 'Python', 'Java'],
  },
  {
    code: 'U',
    className: '交通运输',
    description: '综合运输、铁路、公路、水路、航空',
    subClasses: [
      { code: 'U4', name: '公路运输', description: '汽车工程、道路工程' },
    ],
    location: '五层图书借阅区 U类',
    keywords: ['交通', '汽车', '铁路', '航空', '运输'],
  },
  {
    code: 'V',
    className: '航空、航天',
    description: '航空与航天技术、飞行器',
    subClasses: [
      { code: 'V2', name: '航空', description: '飞机、航空发动机' },
    ],
    location: '五层图书借阅区 V类',
    keywords: ['航空', '航天', '飞行器', '火箭'],
  },
  {
    code: 'X',
    className: '环境科学、安全科学',
    description: '环境科学理论、环境治理、安全科学',
    subClasses: [
      { code: 'X2', name: '环境与环境科学', description: '生态环境、可持续发展' },
      { code: 'X9', name: '安全科学', description: '安全管理、劳动保护' },
    ],
    location: '五层图书借阅区 X类',
    keywords: ['环境', '生态', '污染', '安全', '环保'],
  },
  {
    code: 'Z',
    className: '综合性图书',
    description: '丛书、百科全书、辞典、年鉴、期刊、论文集',
    subClasses: [
      { code: 'Z2', name: '百科全书', description: '综合性百科全书' },
      { code: 'Z3', name: '辞典', description: '各类专业辞典' },
      { code: 'Z5', name: '年鉴', description: '综合性/专业性年鉴' },
    ],
    location: '五层图书借阅区 Z类',
    keywords: ['百科全书', '辞典', '年鉴', '文集', '丛书'],
  },
];
 
export const CALL_NUMBER_RULES = {
  description: '索书号 = 分类号 + 种次号/著者号',
  format: '分类号在前（大写字母+数字），种次号在后（数字）',
  example: 'TP391.13/123 → TP391.13为计算机应用分类，123为种次号',
  reading: '按字母顺序和数字大小依次排列查找',
};