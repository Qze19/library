/**
 * 知识库二：借阅异常诊断库
 * 涵盖常见的借阅异常场景、症状、原因和解决方案
 */
 
export interface DiagnosticEntry {
  id: string;
  category: 'borrow' | 'return' | 'renew' | 'reserve' | 'fine' | 'account' | 'system';
  symptom: string;
  symptoms: string[];
  possibleCauses: string[];
  solutions: string[];
  severity: 'low' | 'medium' | 'high' | 'critical';
  selfService: boolean;
  tags: string[];
}
 
export const BORROWING_DIAGNOSTIC_KB: DiagnosticEntry[] = [
  // ===== 借阅异常 =====
  {
    id: 'diag-001',
    category: 'borrow',
    symptom: '借书时提示"已达最大借阅册数"',
    symptoms: ['借不了书', '提示最大借阅册数', '借阅数量超限', '无法继续借阅'],
    possibleCauses: [
      '当前在借图书已达上限（本科生20册/研究生30册/教师40册）',
      '有逾期未还图书导致部分借阅权限被限制',
      '预约到书未及时领取被计入在借数量',
    ],
    solutions: [
      '归还部分在借图书后再借新书',
      '检查是否有逾期图书，先归还逾期图书',
      '查看"我的借阅"确认实际在借数量',
      '如有预约到书未领取，请先前往服务台取书或取消预约',
    ],
    severity: 'low',
    selfService: true,
    tags: ['借阅', '册数', '上限', '借不了'],
  },
  {
    id: 'diag-002',
    category: 'borrow',
    symptom: '借书时提示"读者证已过期/被冻结"',
    symptoms: ['借不了书', '证过期', '冻结', '无法借阅', '读者证异常'],
    possibleCauses: [
      '读者证已过期（毕业生/离职人员）',
      '有严重逾期或罚款未处理',
      '读者证挂失中',
      '违反图书馆规定被限制借阅',
    ],
    solutions: [
      '前往服务台核实读者证状态',
      '缴清所有罚款和逾期费用',
      '如已挂失需先办理解挂',
      '毕业生需确认借阅权限有效期',
    ],
    severity: 'high',
    selfService: false,
    tags: ['冻结', '过期', '挂失', '停借'],
  },
  {
    id: 'diag-003',
    category: 'borrow',
    symptom: '借书时提示"图书不可借"或"仅限阅览"',
    symptoms: ['借不了书', '不可借', '仅限阅览', '馆内阅览'],
    possibleCauses: [
      '该图书为保留本/库本，仅供馆内阅览',
      '该图书为工具书（辞典、年鉴等），不外借',
      '该图书已被其他读者预约',
      '该图书处于"加工中"或"修补中"状态',
    ],
    solutions: [
      '确认该图书的馆藏状态：保留本/库本只能在馆内阅览',
      '查询是否有其他复本可供外借',
      '如被预约可排队等待，或申请馆际互借',
      '工具书类请使用馆内阅览区',
    ],
    severity: 'low',
    selfService: true,
    tags: ['不可借', '仅限阅览', '保留本', '库本'],
  },
  {
    id: 'diag-004',
    category: 'borrow',
    symptom: '自助借还机扫描图书条码无反应',
    symptoms: ['条码扫不上', '扫描失败', '机器没反应', '借不了书'],
    possibleCauses: [
      '图书条码破损或污损',
      '自助设备故障（网络或硬件问题）',
      '图书RFID标签损坏或未激活',
      '操作姿势不正确（扫描距离或角度不合适）',
    ],
    solutions: [
      '重新摆正图书，调整扫描角度和距离',
      '更换另一台自助借还机重试',
      '如图书条码明显损坏，前往服务台人工处理',
      '如多台设备均无法使用，可能是系统问题，请稍后再试',
    ],
    severity: 'low',
    selfService: true,
    tags: ['条码', '扫描', '自助借还机', '机器故障'],
  },
 
  // ===== 归还异常 =====
  {
    id: 'diag-005',
    category: 'return',
    symptom: '还书时提示"图书逾期，请缴纳罚款"',
    symptoms: ['逾期', '罚款', '还不了书', '超期', '需要缴费'],
    possibleCauses: [
      '图书已超过借阅期限',
      '累计罚款金额达到一定额度',
      '该图书被他人预约，逾期罚款加倍',
    ],
    solutions: [
      '在自助缴费机或线上缴纳罚款（每册每天0.1元）',
      '确认罚款金额后通过校园卡支付',
      '如有特殊情况（因病等），可申请减免',
      '建议开启"到期提醒"功能避免再次逾期',
    ],
    severity: 'medium',
    selfService: true,
    tags: ['逾期', '罚款', '缴费', '超期'],
  },
  {
    id: 'diag-006',
    category: 'return',
    symptom: '还书时提示"图书不属于本馆/无法识别"',
    symptoms: ['还不了书', '无法识别', '不属于本馆', '归还失败'],
    possibleCauses: [
      '图书来自其他图书馆（馆际互借未通过指定渠道归还）',
      '图书RFID/条码信息已从系统中移除',
      '图书为赠书/非正式馆藏',
      '系统数据未同步',
    ],
    solutions: [
      '确认是否通过馆际互借借入，如是需走馆际互借归还流程',
      '前往服务台人工核查图书信息',
      '如为系统问题，工作人员将手动处理',
    ],
    severity: 'medium',
    selfService: false,
    tags: ['无法识别', '非本馆', '馆际互借', '归还失败'],
  },
 
  // ===== 续借异常 =====
  {
    id: 'diag-007',
    category: 'renew',
    symptom: '续借操作失败"该图书已被预约"',
    symptoms: ['续借失败', '被预约', '无法续借', '有人排队'],
    possibleCauses: [
      '其他读者已对该书发起预约请求',
      '该书为热门图书，预约队列已满',
    ],
    solutions: [
      '按期归还，无法续借',
      '可自行对该书发起预约，等待下一轮借阅',
      '查询电子版是否可替代使用',
    ],
    severity: 'medium',
    selfService: true,
    tags: ['续借', '预约', '排队', '热门图书'],
  },
  {
    id: 'diag-008',
    category: 'renew',
    symptom: '续借操作失败"已达最大续借次数"',
    symptoms: ['续借失败', '续借次数', '无法续借', '已经续借过'],
    possibleCauses: [
      '该图书已续借达到最大次数（一般图书2次，热门图书1次）',
    ],
    solutions: [
      '按期归还图书',
      '归还后如有需要可重新借阅（如未被预约）',
      '查询是否有电子版本可继续使用',
    ],
    severity: 'low',
    selfService: true,
    tags: ['续借', '续借次数', '上限'],
  },
 
  // ===== 预约异常 =====
  {
    id: 'diag-009',
    category: 'reserve',
    symptom: '预约失败"已有相同图书在借"',
    symptoms: ['预约失败', '已有在借', '无法预约', '重复预约'],
    possibleCauses: [
      '当前已有该书在借，不能预约自己已借的图书',
      '系统检测到重复预约',
    ],
    solutions: [
      '确认当前借阅列表中是否已有该书',
      '如需再次借阅，请先归还已借的复本',
    ],
    severity: 'low',
    selfService: true,
    tags: ['预约', '重复', '在借'],
  },
  {
    id: 'diag-010',
    category: 'reserve',
    symptom: '预约到书后未收到通知',
    symptoms: ['没收到通知', '预约到书', '不知道书到了'],
    possibleCauses: [
      '联系方式未更新（手机号/邮箱已变更）',
      '通知被拦截（短信拦截/邮件垃圾箱）',
      '系统通知延迟',
      '预约到书保留期已过',
    ],
    solutions: [
      '登录图书馆系统更新个人联系方式',
      '检查短信拦截设置和邮箱垃圾箱',
      '主动查看"我的预约"确认预约状态',
      '预约到书保留期为3天，请及时领取',
    ],
    severity: 'low',
    selfService: true,
    tags: ['预约', '通知', '联系方式', '保留期'],
  },
 
  // ===== 罚款/费用异常 =====
  {
    id: 'diag-011',
    category: 'fine',
    symptom: '对罚款金额有疑问',
    symptoms: ['罚款不对', '多扣了', '费用疑问', '罚款计算'],
    possibleCauses: [
      '逾期天数计算可能有误',
      '可能有多种罚款叠加（逾期+预约未取）',
      '系统计费延迟导致显示不一致',
    ],
    solutions: [
      '前往服务台查询详细罚款明细',
      '提供借阅记录与工作人员核对',
      '如有误可申请人工更正',
    ],
    severity: 'medium',
    selfService: false,
    tags: ['罚款', '费用', '计费', '争议'],
  },
 
  // ===== 账户异常 =====
  {
    id: 'diag-012',
    category: 'account',
    symptom: '登录图书馆系统失败"账号不存在/密码错误"',
    symptoms: ['登录失败', '账号', '密码', '登不上'],
    possibleCauses: [
      '校园卡/统一认证账号未激活图书馆权限',
      '密码输错次数过多被临时锁定',
      '新生数据尚未同步到图书馆系统',
      '使用非在校状态的账号',
    ],
    solutions: [
      '确认使用统一认证账号（学号/工号）登录',
      '如忘记密码请通过学校统一认证系统找回',
      '新生请在入学后1-2周重试，等待数据同步',
      '如持续无法登录，携带校园卡前往服务台处理',
    ],
    severity: 'high',
    selfService: false,
    tags: ['登录', '账号', '密码', '认证'],
  },
];