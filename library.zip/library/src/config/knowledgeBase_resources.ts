/**
 * 知识库四：资源缺失/目录库
 * 记录馆藏缺失的资源、读者荐购需求、电子资源导航
 */
 
export interface MissingResource {
  id: string;
  type: 'missing_book' | 'damaged_book' | 'not_in_collection' | 'out_of_print';
  title: string;
  author?: string;
  publisher?: string;
  status: string;
  alternativeAccess?: string;
  notes: string;
}
 
export interface ElectronicResource {
  id: string;
  name: string;
  category: 'database' | 'ejournal' | 'ebook' | 'multimedia' | 'tool';
  url: string;
  accessMode: 'open' | 'campus_ip' | 'vpn' | 'account';
  description: string;
  subjects: string[];
}
 
export const MISSING_RESOURCES_KB: MissingResource[] = [
  {
    id: 'mr-001',
    type: 'not_in_collection',
    title: '深度学习（花书）中文版',
    author: 'Ian Goodfellow',
    publisher: '人民邮电出版社',
    status: '已列入采购计划，预计3月到馆',
    alternativeAccess: '可通过IEEE Xplore访问英文原版电子书',
    notes: '多位读者推荐，已优先采购',
  },
  {
    id: 'mr-002',
    type: 'missing_book',
    title: 'Python数据科学手册',
    author: 'Jake VanderPlas',
    publisher: '机械工业出版社',
    status: '已遗失，正在补购中',
    alternativeAccess: '可通过O\'Reilly电子书平台在线阅读',
    notes: '索书号TP311.561/234，原馆藏2册均已遗失',
  },
  {
    id: 'mr-003',
    type: 'damaged_book',
    title: '百年孤独（50周年纪念版）',
    author: '加西亚·马尔克斯',
    publisher: '南海出版公司',
    status: '严重破损，已送修，暂不可借',
    alternativeAccess: '电子版可在超星电子书平台阅读',
    notes: '预计修复周期约2周',
  },
  {
    id: 'mr-004',
    type: 'not_in_collection',
    title: 'GPT-4与大规模语言模型实战',
    status: '读者推荐中，评估通过后将采购',
    alternativeAccess: '暂无替代资源，建议关注Packt电子书平台',
    notes: '人工智能方向新书，正在评估采购必要性',
  },
  {
    id: 'mr-005',
    type: 'out_of_print',
    title: '结构人类学',
    author: '克洛德·列维-斯特劳斯',
    status: '已绝版，无法采购新书',
    alternativeAccess: '可通过馆际互借从其他高校获取',
    notes: '1989年版已绝版，建议通过馆际互借满足需求',
  },
];
 
export const ELECTRONIC_RESOURCES_KB: ElectronicResource[] = [
  {
    id: 'er-001',
    name: '中国知网（CNKI）',
    category: 'database',
    url: 'https://www.cnki.net',
    accessMode: 'campus_ip',
    description: '中国最大的中文学术资源库，涵盖期刊、博硕士论文、会议论文、报纸、年鉴等',
    subjects: ['综合', '中文', '期刊', '学位论文'],
  },
  {
    id: 'er-002',
    name: '万方数据知识服务平台',
    category: 'database',
    url: 'https://www.wanfangdata.com.cn',
    accessMode: 'campus_ip',
    description: '中文学术资源平台，包括期刊论文、学位论文、会议论文、专利等',
    subjects: ['综合', '中文', '期刊', '专利'],
  },
  {
    id: 'er-003',
    name: 'Web of Science',
    category: 'database',
    url: 'https://www.webofscience.com',
    accessMode: 'campus_ip',
    description: '全球权威的学术引文索引数据库，涵盖SCI/SSCI/A&HCI等',
    subjects: ['综合', '英文', '引文索引', 'SCI'],
  },
  {
    id: 'er-004',
    name: 'IEEE Xplore',
    category: 'database',
    url: 'https://ieeexplore.ieee.org',
    accessMode: 'campus_ip',
    description: 'IEEE出版的电子工程、计算机科学领域全文数据库',
    subjects: ['电子工程', '计算机', '通信', '自动化'],
  },
  {
    id: 'er-005',
    name: 'Elsevier ScienceDirect',
    category: 'ejournal',
    url: 'https://www.sciencedirect.com',
    accessMode: 'campus_ip',
    description: 'Elsevier出版的学术期刊全文数据库，覆盖自然科学、工程技术、医学等',
    subjects: ['自然科学', '医学', '工程', '社会科学'],
  },
  {
    id: 'er-006',
    name: '超星电子书',
    category: 'ebook',
    url: 'https://www.sslibrary.com',
    accessMode: 'campus_ip',
    description: '中文电子书平台，收录百万种中文图书全文',
    subjects: ['综合', '中文', '电子书'],
  },
  {
    id: 'er-007',
    name: 'O\'Reilly for Higher Education',
    category: 'ebook',
    url: 'https://www.oreilly.com/library',
    accessMode: 'account',
    description: '技术类和商业类电子书、视频、案例学习平台',
    subjects: ['计算机', '商业', '数据科学', '人工智能'],
  },
  {
    id: 'er-008',
    name: '新东方多媒体学习库',
    category: 'multimedia',
    url: 'https://library.koolearn.com',
    accessMode: 'campus_ip',
    description: '英语四六级、考研英语、出国考试等在线学习资源',
    subjects: ['英语', '考试', '四六级', '考研', '雅思托福'],
  },
  {
    id: 'er-009',
    name: 'NoteExpress',
    category: 'tool',
    url: 'https://www.inoteexpress.com',
    accessMode: 'campus_ip',
    description: '参考文献管理软件，支持文献检索、管理、引用格式化',
    subjects: ['文献管理', '论文写作', '引用'],
  },
  {
    id: 'er-010',
    name: 'EndNote',
    category: 'tool',
    url: 'https://endnote.com',
    accessMode: 'campus_ip',
    description: '国际通用的参考文献管理工具，与Web of Science深度集成',
    subjects: ['文献管理', '论文写作', 'SCI'],
  },
];