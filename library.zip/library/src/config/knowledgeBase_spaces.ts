/**
 * 知识库一：空间与时间库
 * 数据来源：《04-01_楼层功能分区与场馆导航_v0.2》《01-01_入馆与借阅业务规则_v0.2》
 * 武汉职业技术大学图书馆：共四层，每层分 A区 / B区
 *   一层：A区 馆员工作区 / B区 休闲文化区
 *   二至四层：A区 综合服务区 / B区 学习中心区
 * 开放时间（关山总馆）：周一至周日 8:00—21:00，节假日另行通知
 */

export interface SpaceInfo {
  id: string;
  name: string;
  category:
    | 'reading'
    | 'study'
    | 'discussion'
    | 'exhibition'
    | 'multimedia'
    | 'maker'
    | 'relaxation'
    | 'service'
    | 'collection'
    | 'staff';
  floor: number;
  zone: 'A区' | 'B区';
  /** 馆内方位描述，如 "西入口旁"、"B区东侧" */
  position?: string;
  /** 座位容量；0 表示未在文档中标注 */
  capacity: number;
  openTime: string;
  closeTime: string;
  requiresReservation: boolean;
  facilities: string[];
  rules: string[];
  description: string;
  /** 读者常用点位标记 */
  readerFavorite?: boolean;
}

export interface TimeRule {
  id: string;
  type: 'regular' | 'holiday' | 'exam_week' | 'vacation';
  weekdayOpen: string;
  weekdayClose: string;
  weekendOpen: string;
  weekendClose: string;
  appliesTo: string[];
  effectivePeriod: string;
}

export const SPACE_KNOWLEDGE_BASE: SpaceInfo[] = [
  // ===== 一层 1F =====
  {
    id: 'sp-101',
    name: '密集书库',
    category: 'collection',
    floor: 1,
    zone: 'A区',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: [],
    rules: ['闭架管理，读者不直接进入', '需通过检索系统查询并由馆员协助获取'],
    description: '闭架藏书空间，读者不可直接进入，需通过馆藏检索后由馆员协助获取。',
  },
  {
    id: 'sp-102',
    name: '储藏书库1 / 储藏书库2',
    category: 'collection',
    floor: 1,
    zone: 'A区',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: [],
    rules: ['闭架管理，读者不直接进入', '需通过检索系统查询并由馆员协助获取'],
    description: '闭架藏书空间，读者不可直接进入。',
  },
  {
    id: 'sp-103',
    name: '教材库 / 临时书库 / 图书加工室',
    category: 'staff',
    floor: 1,
    zone: 'A区',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: [],
    rules: ['业务用房，读者不直接进入'],
    description: '馆员业务用房，不对外开放。',
  },
  {
    id: 'sp-104',
    name: '休闲阅览区（一层）',
    category: 'relaxation',
    floor: 1,
    zone: 'B区',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['休闲座椅'],
    rules: ['轻声交谈'],
    description: '一层休闲文化区阅览空间，氛围轻松。',
    readerFavorite: true,
  },
  {
    id: 'sp-105',
    name: '新书展示区（一层）',
    category: 'exhibition',
    floor: 1,
    zone: 'B区',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['新书展架'],
    rules: ['阅后请归位'],
    description: '展示最新到馆图书，可就地阅览。',
    readerFavorite: true,
  },
  {
    id: 'sp-106',
    name: '漂流书墙',
    category: 'relaxation',
    floor: 1,
    zone: 'B区',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['漂流书墙'],
    rules: ['取阅后欢迎放回或传递下一位读者'],
    description: '图书漂流共享空间，自由取阅、自由放回。',
    readerFavorite: true,
  },
  {
    id: 'sp-107',
    name: '咖啡吧自购区',
    category: 'relaxation',
    floor: 1,
    zone: 'B区',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: [],
    rules: ['待建状态，尚未开放', '馆内饮食规定以入馆须知为准'],
    description: '规划中咖啡吧，目前尚未开放。',
  },

  // ===== 二层 2F =====
  {
    id: 'sp-201',
    name: '读者服务部',
    category: 'service',
    floor: 2,
    zone: 'A区',
    position: '西入口旁',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['业务办理窗口'],
    rules: [],
    description: '咨询与业务办理首选点位（借还书、办证、异常处理等）。',
    readerFavorite: true,
  },
  {
    id: 'sp-202',
    name: '公共文化展厅 / 文化长廊展示区',
    category: 'exhibition',
    floor: 2,
    zone: 'A区',
    position: '中部',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['展板', '展柜'],
    rules: ['禁止触摸展品', '保持安静'],
    description: '定期举办文化展览与主题展示。',
  },
  {
    id: 'sp-203',
    name: '新书展示区（二层）',
    category: 'exhibition',
    floor: 2,
    zone: 'A区',
    position: '中部',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['新书展架'],
    rules: ['阅后请归位'],
    description: '二层新书展示，可就地阅览。',
    readerFavorite: true,
  },
  {
    id: 'sp-204',
    name: '创客学习空间',
    category: 'maker',
    floor: 2,
    zone: 'A区',
    position: 'A区北侧',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['创客工位', '实践设备'],
    rules: ['以现场使用规则为准'],
    description: '创意实践与协作学习空间，适合小组项目与动手实践。',
    readerFavorite: true,
  },
  {
    id: 'sp-205',
    name: '研修空间（二层）',
    category: 'discussion',
    floor: 2,
    zone: 'A区',
    position: 'A区南侧',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['研修桌椅'],
    rules: ['轻声讨论'],
    description: '小组研修与讨论空间。',
    readerFavorite: true,
  },
  {
    id: 'sp-206',
    name: '红色阅览区',
    category: 'reading',
    floor: 2,
    zone: 'A区',
    position: 'A区南侧',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['红色文献专架', '阅览桌椅'],
    rules: ['保持安静'],
    description: '红色文献与党建主题阅览专区。',
    readerFavorite: true,
  },
  {
    id: 'sp-207',
    name: '安静阅览区（二层B区）',
    category: 'reading',
    floor: 2,
    zone: 'B区',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['阅览桌椅', '馆藏书架'],
    rules: ['保持安静', '手机请调静音'],
    description: '二层学习中心安静阅览区。',
    readerFavorite: true,
  },
  {
    id: 'sp-208',
    name: '藏书区（二层B区）',
    category: 'collection',
    floor: 2,
    zone: 'B区',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['开架书架'],
    rules: ['是否开架自行取阅以现场标识与馆员指引为准'],
    description: '二层开架藏书区，按索书号排架。',
  },
  {
    id: 'sp-209',
    name: '开放学习区（二层）',
    category: 'study',
    floor: 2,
    zone: 'B区',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['学习桌椅', '电源'],
    rules: ['请勿长时间占座'],
    description: '二层开放学习空间，适合自习与课业学习。',
    readerFavorite: true,
  },
  {
    id: 'sp-210',
    name: '休闲阅览区（二层）',
    category: 'relaxation',
    floor: 2,
    zone: 'B区',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['休闲座椅'],
    rules: ['轻声交谈'],
    description: '二层休闲阅读空间。',
  },
  {
    id: 'sp-211',
    name: '总服务台',
    category: 'service',
    floor: 2,
    zone: 'B区',
    position: 'B区东侧',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['咨询台', '业务办理'],
    rules: [],
    description: '二层总服务台，综合咨询与业务办理。',
    readerFavorite: true,
  },

  // ===== 三层 3F =====
  {
    id: 'sp-301',
    name: '共享学习空间（三层）',
    category: 'study',
    floor: 3,
    zone: 'A区',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['共享桌椅'],
    rules: ['轻声讨论'],
    description: '三层协作学习空间。',
    readerFavorite: true,
  },
  {
    id: 'sp-302',
    name: '安静阅览区（三层A区）',
    category: 'reading',
    floor: 3,
    zone: 'A区',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['阅览桌椅'],
    rules: ['保持安静'],
    description: '三层A区安静阅览区。',
  },
  {
    id: 'sp-303',
    name: '研修空间（三层）',
    category: 'discussion',
    floor: 3,
    zone: 'A区',
    position: 'A区南侧与中部',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['研修桌椅'],
    rules: ['轻声讨论'],
    description: '三层研修空间。',
  },
  {
    id: 'sp-304',
    name: '特藏区',
    category: 'reading',
    floor: 3,
    zone: 'A区',
    position: 'A区南侧与中部',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['特藏书架', '阅览桌椅'],
    rules: ['特藏文献阅览规则以现场标识为准'],
    description: '特色馆藏文献阅览区。',
    readerFavorite: true,
  },
  {
    id: 'sp-305',
    name: '阅享天地（三层）',
    category: 'relaxation',
    floor: 3,
    zone: 'A区',
    position: '中部连廊',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['休闲阅读设施'],
    rules: [],
    description: '三层中部连廊阅读空间。',
    readerFavorite: true,
  },
  {
    id: 'sp-306',
    name: '开放学习区（三层）',
    category: 'study',
    floor: 3,
    zone: 'B区',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['学习桌椅'],
    rules: ['请勿长时间占座'],
    description: '三层开放学习空间。',
    readerFavorite: true,
  },
  {
    id: 'sp-307',
    name: '安静阅览区（三层B区）',
    category: 'reading',
    floor: 3,
    zone: 'B区',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['阅览桌椅'],
    rules: ['保持安静'],
    description: '三层B区安静阅览区。',
  },
  {
    id: 'sp-308',
    name: '藏书区（三层B区）',
    category: 'collection',
    floor: 3,
    zone: 'B区',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['开架书架'],
    rules: ['是否开架自行取阅以现场标识与馆员指引为准'],
    description: '三层开架藏书区，按索书号排架。',
  },
  {
    id: 'sp-309',
    name: '服务台（三层）',
    category: 'service',
    floor: 3,
    zone: 'B区',
    position: 'B区东侧',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['咨询台'],
    rules: [],
    description: '三层服务台，可就近咨询。',
  },

  // ===== 四层 4F =====
  {
    id: 'sp-401',
    name: '资源建设部',
    category: 'staff',
    floor: 4,
    zone: 'A区',
    position: 'A区西北角',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: [],
    rules: ['业务用房，读者不直接进入'],
    description: '馆员业务用房。',
  },
  {
    id: 'sp-402',
    name: '共享学习空间（四层）',
    category: 'study',
    floor: 4,
    zone: 'A区',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['共享桌椅'],
    rules: ['轻声讨论'],
    description: '四层协作学习空间。',
  },
  {
    id: 'sp-403',
    name: '安静阅览区（四层A区）',
    category: 'reading',
    floor: 4,
    zone: 'A区',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['阅览桌椅'],
    rules: ['保持安静'],
    description: '四层A区安静阅览区。',
  },
  {
    id: 'sp-404',
    name: '阅享天地（四层）',
    category: 'relaxation',
    floor: 4,
    zone: 'A区',
    position: '中部',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['休闲阅读设施'],
    rules: [],
    description: '四层中部阅读空间。',
  },
  {
    id: 'sp-405',
    name: '期刊阅览区',
    category: 'reading',
    floor: 4,
    zone: 'A区',
    position: '中部南侧',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['期刊架', '报刊架', '阅览桌椅'],
    rules: ['期刊阅后归位'],
    description: '中外文期刊、报纸阅览区。',
    readerFavorite: true,
  },
  {
    id: 'sp-406',
    name: '开放学习区（四层）',
    category: 'study',
    floor: 4,
    zone: 'B区',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['学习桌椅'],
    rules: ['请勿长时间占座'],
    description: '四层开放学习空间。',
    readerFavorite: true,
  },
  {
    id: 'sp-407',
    name: '安静阅览区（四层B区）',
    category: 'reading',
    floor: 4,
    zone: 'B区',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['阅览桌椅'],
    rules: ['保持安静'],
    description: '四层B区安静阅览区。',
    readerFavorite: true,
  },
  {
    id: 'sp-408',
    name: '藏书区（四层B区）',
    category: 'collection',
    floor: 4,
    zone: 'B区',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['开架书架'],
    rules: ['是否开架自行取阅以现场标识与馆员指引为准'],
    description: '四层开架藏书区，按索书号排架。',
  },
  {
    id: 'sp-409',
    name: '服务台（四层）',
    category: 'service',
    floor: 4,
    zone: 'B区',
    position: 'B区东侧',
    capacity: 0,
    openTime: '08:00',
    closeTime: '21:00',
    requiresReservation: false,
    facilities: ['咨询台'],
    rules: [],
    description: '四层服务台，可就近咨询。',
  },
];

export const TIME_RULES: TimeRule[] = [
  {
    id: 'tr-001',
    type: 'regular',
    weekdayOpen: '08:00',
    weekdayClose: '21:00',
    weekendOpen: '08:00',
    weekendClose: '21:00',
    appliesTo: SPACE_KNOWLEDGE_BASE.map((s) => s.id),
    effectivePeriod: '全馆常规开放（周一至周日）',
  },
  {
    id: 'tr-002',
    type: 'holiday',
    weekdayOpen: '以官网通知为准',
    weekdayClose: '以官网通知为准',
    weekendOpen: '以官网通知为准',
    weekendClose: '以官网通知为准',
    appliesTo: [],
    effectivePeriod: '法定节假日，以图书馆官网通知为准',
  },
];

/** 楼层概览（用于对话答复与导览） */
export const FLOOR_MAP: Record<number, string> = {
  1: '一层：A区 馆员工作区（密集书库/储藏书库/教材库，闭架） · B区 休闲文化区（休闲阅览区/新书展示区/漂流书墙）；北入口（闸机）、南入口（通下沉式庭院）',
  2: '二层：A区 综合服务区（读者服务部/展厅/新书展示/创客学习空间/研修空间/红色阅览区） · B区 学习中心区（安静阅览区/藏书区/开放学习区/总服务台东侧）；西入口、东入口（均设闸机）',
  3: '三层：A区 综合服务区（共享学习空间/研修空间/特藏区） · B区 学习中心区（开放学习区/安静阅览区/藏书区/服务台东侧）；中部连廊为阅享天地',
  4: '四层：A区 综合服务区（共享学习空间/安静阅览区/期刊阅览区中部南侧） · B区 学习中心区（开放学习区/安静阅览区/藏书区/服务台东侧）；中部为阅享天地',
};

/** 出入口与闸机 */
export const ENTRANCES = [
  { name: '北入口', floor: 1, note: '设进馆闸机', direction: '北' },
  { name: '南入口', floor: 1, note: '通下沉式庭院（无闸机）', direction: '南' },
  { name: '西入口', floor: 2, note: '设进馆闸机，旁为读者服务部', direction: '西' },
  { name: '东入口', floor: 2, note: '设进馆闸机', direction: '东' },
];

/** 高频导航问答（来源：文档"导航问答指引"） */
export interface NavQA {
  id: string;
  question: string;
  keywords: string[];
  answer: string;
}

export const NAV_QA_GUIDE: NavQA[] = [
  {
    id: 'qa-01',
    question: '新书在哪看？',
    keywords: ['新书', '新书上架'],
    answer:
      '新书展示区有两个：一层B区新书展示区、二层中部新书展示区。推荐先去二层中部的新书展示区，面积更大、更新更快。',
  },
  {
    id: 'qa-02',
    question: '借还书/办业务找谁？',
    keywords: ['借还书', '办业务', '办证', '找谁'],
    answer:
      '首选二层读者服务部（西入口旁）或二层总服务台（B区东侧）；在三、四层的话可就近咨询本层服务台（均在B区东侧）。',
  },
  {
    id: 'qa-03',
    question: '安静自习去哪？',
    keywords: ['自习', '安静'],
    answer:
      '二、三、四层B区均设安静阅览区；三层、四层A区也有安静阅览区。追求最安静环境推荐B区安静阅览区。',
  },
  {
    id: 'qa-04',
    question: '小组讨论/协作学习去哪？',
    keywords: ['小组', '讨论', '协作'],
    answer:
      '可选二层创客学习空间（A区北侧）、二层研修空间（A区南侧）；三、四层共享学习空间与阅享天地也适合小组协作。',
  },
  {
    id: 'qa-05',
    question: '期刊报纸在哪？',
    keywords: ['期刊', '报纸', '报刊', '杂志'],
    answer: '期刊阅览区在四层中部南侧，中外文期刊、报纸均在四层取阅。',
  },
  {
    id: 'qa-06',
    question: '特色馆藏/特藏在哪？',
    keywords: ['特藏', '特色馆藏'],
    answer: '特藏区在三层A区南侧与中部。',
  },
  {
    id: 'qa-07',
    question: '红色文献/党建阅读在哪？',
    keywords: ['红色', '党建'],
    answer: '红色阅览区在二层A区南侧。',
  },
  {
    id: 'qa-08',
    question: '从哪个门进？',
    keywords: ['入口', '哪个门', '闸机', '怎么进'],
    answer:
      '一层北入口、二层西入口、二层东入口均设进馆闸机（可刷校园卡或人脸识别）；一层南入口通下沉式庭院。二层西入口旁就是读者服务部，办业务最顺路。',
  },
  {
    id: 'qa-09',
    question: '咖啡/餐饮？',
    keywords: ['咖啡', '餐饮', '吃饭', '饮料'],
    answer: '一层咖啡吧为待建状态，尚未开放；馆内禁止饮食，具体以入馆须知为准。',
  },
  {
    id: 'qa-10',
    question: '藏书区能否自行取阅？',
    keywords: ['取阅', '开架', '闭架', '书库'],
    answer:
      '一层密集书库与储藏书库为闭架管理，读者不直接进入，需通过检索系统查询后由馆员协助获取；各层藏书区是否开架自行取阅，以现场标识与馆员指引为准。',
  },
];

/** 在知识库中按名称/关键词查找点位 */
export function findSpaces(keyword: string): SpaceInfo[] {
  const kw = keyword.toLowerCase();
  return SPACE_KNOWLEDGE_BASE.filter(
    (s) =>
      s.name.toLowerCase().includes(kw) ||
      s.description.toLowerCase().includes(kw) ||
      s.facilities.some((f) => f.toLowerCase().includes(kw)),
  );
}
