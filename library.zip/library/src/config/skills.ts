/**
 * 技能配置 — 智图灵伴智能体技能设置
 * 包含：文献传递、资源推荐（按标签）、联网搜索、自定义借阅状态查询
 */
 
export interface SkillConfig {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  category: 'core' | 'optional' | 'external';
  requiresAuth: boolean;
  config: Record<string, unknown>;
}
 
export interface ResourceRecommendTag {
  id: string;
  name: string;
  category: 'subject' | 'level' | 'format' | 'popularity';
  weight: number;
}
 
export const SKILL_CONFIGS: SkillConfig[] = [
  {
    id: 'skill-document-delivery',
    name: '文献传递',
    description: '帮助用户通过馆际互借和文献传递服务获取本馆未收藏的文献资源',
    enabled: true,
    category: 'core',
    requiresAuth: true,
    config: {
      providers: ['CALIS', 'CASHL', 'NSTL'],
      maxPagesPerRequest: 50,
      estimatedTime: '3-7个工作日',
      costInfo: '期刊论文每篇5元补贴后免费，图书每册20元',
      supportedFormats: ['期刊论文', '学位论文', '会议论文', '图书章节', '专利', '标准'],
    },
  },
  {
    id: 'skill-resource-recommend',
    name: '资源推荐（按标签）',
    description: '根据用户学科背景、借阅历史和兴趣标签，智能推荐馆藏资源和电子资源',
    enabled: true,
    category: 'core',
    requiresAuth: true,
    config: {
      algorithm: 'collaborative_filtering',
      maxRecommendations: 10,
      freshnessDays: 90,
      tagWeights: {
        subject_match: 0.4,
        popularity: 0.2,
        recency: 0.2,
        user_history: 0.2,
      },
    },
  },
  {
    id: 'skill-web-search',
    name: '联网搜索',
    description: '当知识库无法覆盖用户问题时，启用联网搜索获取最新信息',
    enabled: true,
    category: 'external',
    requiresAuth: false,
    config: {
      searchEngines: ['内置搜索引擎'],
      maxResults: 5,
      fallbackOnly: true,
      sourceCitation: true,
      domains: ['edu.cn', 'cas.cn', 'library'],
    },
  },
  {
    id: 'skill-borrowing-status',
    name: '自定义借阅状态查询',
    description: '查询个人借阅状态，包含当前借阅、历史借阅、预约状态、罚款信息等',
    enabled: false,
    category: 'optional',
    requiresAuth: true,
    config: {
      queryTypes: ['current_loans', 'loan_history', 'reservations', 'fines', 'reading_history'],
      defaultDays: 30,
      autoRemindBefore: 3,
    },
  },
];
 
export const RESOURCE_RECOMMEND_TAGS: ResourceRecommendTag[] = [
  // 学科标签
  { id: 'tag-001', name: '计算机科学与技术', category: 'subject', weight: 0.9 },
  { id: 'tag-002', name: '人工智能', category: 'subject', weight: 0.95 },
  { id: 'tag-003', name: '数据科学', category: 'subject', weight: 0.9 },
  { id: 'tag-004', name: '软件工程', category: 'subject', weight: 0.85 },
  { id: 'tag-005', name: '电子信息工程', category: 'subject', weight: 0.85 },
  { id: 'tag-006', name: '机械工程', category: 'subject', weight: 0.8 },
  { id: 'tag-007', name: '土木工程', category: 'subject', weight: 0.8 },
  { id: 'tag-008', name: '经济学', category: 'subject', weight: 0.85 },
  { id: 'tag-009', name: '管理学', category: 'subject', weight: 0.85 },
  { id: 'tag-010', name: '法学', category: 'subject', weight: 0.85 },
  { id: 'tag-011', name: '外国语言文学', category: 'subject', weight: 0.8 },
  { id: 'tag-012', name: '数学', category: 'subject', weight: 0.85 },
  { id: 'tag-013', name: '物理学', category: 'subject', weight: 0.8 },
  { id: 'tag-014', name: '化学', category: 'subject', weight: 0.8 },
  { id: 'tag-015', name: '生物医学工程', category: 'subject', weight: 0.8 },
 
  // 难度级别标签
  { id: 'tag-101', name: '入门', category: 'level', weight: 0.7 },
  { id: 'tag-102', name: '进阶', category: 'level', weight: 0.8 },
  { id: 'tag-103', name: '高级', category: 'level', weight: 0.6 },
  { id: 'tag-104', name: '研究级', category: 'level', weight: 0.5 },
 
  // 资源类型标签
  { id: 'tag-201', name: '纸质图书', category: 'format', weight: 0.7 },
  { id: 'tag-202', name: '电子书', category: 'format', weight: 0.85 },
  { id: 'tag-203', name: '期刊论文', category: 'format', weight: 0.9 },
  { id: 'tag-204', name: '视频课程', category: 'format', weight: 0.6 },
  { id: 'tag-205', name: '代码仓库', category: 'format', weight: 0.5 },
 
  // 热度标签
  { id: 'tag-301', name: '热门借阅', category: 'popularity', weight: 0.75 },
  { id: 'tag-302', name: '新书上架', category: 'popularity', weight: 0.8 },
  { id: 'tag-303', name: '经典必读', category: 'popularity', weight: 0.85 },
  { id: 'tag-304', name: '教授推荐', category: 'popularity', weight: 0.9 },
  { id: 'tag-305', name: '考试参考', category: 'popularity', weight: 0.7 },
];