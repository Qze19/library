/**
 * 工作流四：学术问询多阶段处理工作流
 *
 * 四阶段流水线：
 *   阶段一【意图拆分】→ 阶段二【馆藏匹配】→ 阶段三【联网补充】→ 阶段四【综合答复】
 *
 * 每个阶段产生结构化中间结果，下游阶段可感知上游输出。
 */
 
// ===== 阶段输出类型 =====
 
export interface ParsedAcademicIntent {
  topic: string;
  keywords: string[];
  subjects: string[];
  resourceType: 'book' | 'paper' | 'textbook' | 'reference' | 'general';
  detailLevel: 'brief' | 'normal' | 'comprehensive';
  originalQuery: string;
}
 
export interface HoldingsMatchItem {
  type: 'physical' | 'ebook';
  id: string;
  title: string;
  author: string;
  detail: string;
  location?: string;
  callNumber?: string;
  status?: string;
  copies?: string;
  url?: string;
  platform?: string;
  accessMode?: string;
  score: number;
}
 
export interface WebSearchSupplement {
  title: string;
  author: string;
  summary: string;
  sourceUrl: string;
  relevance: string;
  searched: boolean;
}
 
export interface AcademicWorkflowStage {
  stage: number;
  name: string;
  description: string;
}
 
export interface AcademicWorkflow {
  id: string;
  name: string;
  description: string;
  triggerIntents: string[];
  stages: AcademicWorkflowStage[];
}
 
export const ACADEMIC_INQUIRY_WORKFLOW: AcademicWorkflow = {
  id: 'wf-academic-inquiry',
  name: '学术问询多阶段处理工作流',
  description:
    '对学术问题进行意图拆分 → 汇总本馆纸质+电子馆藏 → 联网补充缺失信息 → 综合答复',
  triggerIntents: ['academic_inquiry'],
  stages: [
    {
      stage: 1,
      name: '意图拆分',
      description:
        '解析用户学术问题，提取核心主题词、学科领域、资源类型（教材/专著/论文/参考书）和需求深度。对复合问题拆分为多个独立子主题以便分别检索。',
    },
    {
      stage: 2,
      name: '馆藏匹配',
      description:
        '在馆藏资源库中检索匹配的纸质书（返回楼层、区域、索书号、在馆状态）和电子书（返回平台名、跳转URL、访问方式）。优先展示状态为"可借"的纸质书和可全文访问的电子书。',
    },
    {
      stage: 3,
      name: '联网补充',
      description:
        '对馆藏中缺少简介/目录/书评的书籍，或馆藏未覆盖的子主题，通过联网搜索补充书籍简介、目录大纲、读者评价等信息。标记每项补充信息的来源URL。',
    },
    {
      stage: 4,
      name: '综合答复',
      description:
        '汇总阶段二馆藏匹配结果和阶段三联网补充信息，按"馆藏纸质资源 → 馆藏电子资源 → 联网补充 → 相关建议"的结构输出综合答复。包含完整的物理位置、索书号、电子书跳转URL和外部参考链接。',
    },
  ],
};
 
// ===== 意图拆分逻辑 =====
export function parseAcademicIntent(query: string): ParsedAcademicIntent {
  const normalized = query.toLowerCase();
 
  // 提取学科领域
  const subjectMap: Record<string, string[]> = {
    '人工智能': ['人工智能', '机器学习', '深度学习', '神经网络', 'AI', 'NLP', '计算机视觉'],
    '计算机科学': ['计算机', '算法', '数据结构', '编程', '软件', '操作系统', '编译', '网络'],
    '数学': ['数学', '线性代数', '概率', '统计', '微积分', '离散', '优化'],
    '经济学': ['经济', '金融', '宏观', '微观', '计量', '贸易'],
    '心理学': ['心理', '认知', '行为', '社会心理'],
    '数据科学': ['数据', '大数据', '数据挖掘', '数据分析', '可视化'],
    '软件工程': ['软件工程', '设计模式', '重构', '架构', '敏捷', 'DevOps'],
  };
 
  const detectedSubjects: string[] = [];
  const detectedKeywords: string[] = [];
 
  for (const [subject, kws] of Object.entries(subjectMap)) {
    for (const kw of kws) {
      if (normalized.includes(kw.toLowerCase())) {
        if (!detectedSubjects.includes(subject)) detectedSubjects.push(subject);
        detectedKeywords.push(kw);
      }
    }
  }
 
  // 判断资源类型
  let resourceType: ParsedAcademicIntent['resourceType'] = 'book';
  if (normalized.includes('教材') || normalized.includes('课本') || normalized.includes('入门') || normalized.includes('教程')) {
    resourceType = 'textbook';
  } else if (normalized.includes('论文') || normalized.includes('文献') || normalized.includes('期刊')) {
    resourceType = 'paper';
  } else if (normalized.includes('参考') || normalized.includes('手册') || normalized.includes('指南')) {
    resourceType = 'reference';
  }
 
  // 判断需求深度
  let detailLevel: ParsedAcademicIntent['detailLevel'] = 'normal';
  if (normalized.includes('推荐') || normalized.includes('有什么') || normalized.includes('找一本') || normalized.includes('简单')) {
    detailLevel = 'brief';
  } else if (normalized.includes('全部') || normalized.includes('所有') || normalized.includes('详细') || normalized.includes('全面') || normalized.includes('综述')) {
    detailLevel = 'comprehensive';
  }
 
  // 提取核心主题
  const topic = detectedKeywords.length > 0
    ? detectedKeywords.slice(0, 3).join('、')
    : query.slice(0, 30);
 
  return {
    topic,
    keywords: detectedKeywords.length > 0 ? detectedKeywords : [query],
    subjects: detectedSubjects.length > 0 ? detectedSubjects : ['通用'],
    resourceType,
    detailLevel,
    originalQuery: query,
  };
}
 
// ===== 从检索字符串中提取书名 =====
function extractBookTitles(query: string): string[] {
  const titles: string[] = [];
  // 匹配《》中的书名
  const bracketMatch = query.match(/《([^》]+)》/g);
  if (bracketMatch) {
    titles.push(...bracketMatch.map((m) => m.replace(/[《》]/g, '')));
  }
  // 匹配引号中的书名
  const quoteMatch = query.match(/[""]([^""]+)[""]/g);
  if (quoteMatch) {
    titles.push(...quoteMatch.map((m) => m.replace(/[""""]/g, '')));
  }
  return titles;
}
 
// ===== 馆藏匹配函数签名（具体实现见 orchestrator） =====
export type HoldingsSearchFn = (
  query: string,
  parsed: ParsedAcademicIntent,
) => HoldingsMatchItem[];
 
// ===== 联网补充函数签名（具体实现见 orchestrator） =====
export type WebSearchFn = (
  topics: string[],
  existingTitles: string[],
) => Promise<WebSearchSupplement[]>;
 
// ===== 综合答复组装 =====
export function synthesizeAcademicResponse(
  parsed: ParsedAcademicIntent,
  holdings: HoldingsMatchItem[],
  webResults: WebSearchSupplement[],
): string {
  const physicalBooks = holdings.filter((h) => h.type === 'physical');
  const ebooks = holdings.filter((h) => h.type === 'ebook');
 
  let response = `【智图灵伴】您好！\n\n`;
  response += `📋 **问题识别**：🎓 学术问询\n`;
  response += `🔍 **解析主题**：${parsed.topic}\n`;
  response += `📂 **学科领域**：${parsed.subjects.join('、')}\n`;
  response += `📖 **资源类型**：${parsed.resourceType === 'textbook' ? '教材' : parsed.resourceType === 'paper' ? '论文' : parsed.resourceType === 'reference' ? '参考书' : '图书'}\n\n`;
 
  // 分隔线
  response += `━━━━━━━━━━━━━━━━━━━━\n`;
  response += `📚 **一、本馆纸质资源**（${physicalBooks.length}条匹配）\n\n`;
 
  if (physicalBooks.length > 0) {
    physicalBooks.forEach((pb, i) => {
      response += `${i + 1}. **${pb.title}**\n`;
      response += `   👤 作者：${pb.author}\n`;
      response += `   📍 位置：${pb.location} | ${pb.callNumber}\n`;
      response += `   📦 状态：${pb.status} | ${pb.copies}\n`;
      if (pb.detail) response += `   📝 ${pb.detail}\n`;
      response += `\n`;
    });
  } else {
    response += `   ⚠️ 未在馆藏中找到精确匹配的纸质书，建议尝试联网搜索或馆际互借。\n\n`;
  }
 
  response += `━━━━━━━━━━━━━━━━━━━━\n`;
  response += `💻 **二、本馆电子资源**（${ebooks.length}条匹配）\n\n`;
 
  if (ebooks.length > 0) {
    ebooks.forEach((eb, i) => {
      response += `${i + 1}. **${eb.title}**\n`;
      response += `   👤 作者：${eb.author}\n`;
      response += `   🔗 平台：${eb.platform} | [点击访问](${eb.url})\n`;
      response += `   🔑 访问方式：${eb.accessMode}\n`;
      if (eb.detail) response += `   📝 ${eb.detail}\n`;
      response += `\n`;
    });
  } else {
    response += `   ⚠️ 未在馆藏中找到匹配的电子书。\n\n`;
  }
 
  // 联网补充
  if (webResults.length > 0 && webResults.some((w) => w.searched)) {
    response += `━━━━━━━━━━━━━━━━━━━━\n`;
    response += `🌐 **三、联网补充信息**（${webResults.filter((w) => w.searched).length}条）\n\n`;
    webResults.filter((w) => w.searched).forEach((wr, i) => {
      response += `${i + 1}. **${wr.title}**\n`;
      response += `   📝 ${wr.summary}\n`;
      response += `   🔗 来源：[${wr.sourceUrl}](${wr.sourceUrl})\n`;
      response += `   💡 ${wr.relevance}\n\n`;
    });
  }
 
  response += `━━━━━━━━━━━━━━━━━━━━\n`;
  response += `💡 **相关提示**：\n`;
  response += `- 纸质书可凭索书号到对应楼层书架取阅\n`;
  response += `- 电子书请在校内IP或VPN环境下访问\n`;
  response += `- 如馆藏资源无法满足需求，可通过文献传递获取\n`;
  response += `\n📞 **进一步帮助**：如需更深入的学科资源导航，请联系学科馆员或前往图书馆服务台。`;
 
  return response;
}