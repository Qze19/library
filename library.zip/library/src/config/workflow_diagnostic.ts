/**
 * 工作流一：借阅异常诊断工作流
 * 处理用户遇到的各类借阅异常，提供系统化诊断和解决方案
 */
 
export interface DiagnosticWorkflowStep {
  id: string;
  name: string;
  type: 'question' | 'analysis' | 'solution' | 'escalation' | 'confirmation';
  prompt: string;
  nextOnCondition?: { condition: string; nextStep: string }[];
  fallbackStep?: string;
}
 
export interface DiagnosticWorkflow {
  id: string;
  name: string;
  description: string;
  triggerIntents: string[];
  steps: DiagnosticWorkflowStep[];
  maxLoopCount: number;
}
 
export const BORROWING_DIAGNOSTIC_WORKFLOW: DiagnosticWorkflow = {
  id: 'wf-borrowing-diagnostic',
  name: '借阅异常诊断工作流',
  description: '系统化诊断和处理用户的借阅异常问题，覆盖借阅、归还、续借、预约、罚款等场景',
  triggerIntents: ['borrowing_exception'],
  maxLoopCount: 3,
  steps: [
    {
      id: 'step-01',
      name: '异常分类',
      type: 'question',
      prompt: `请描述您遇到的具体问题：
1. 是在借书、还书、续借还是预约时出现的问题？
2. 系统显示了什么提示信息？
3. 您之前是否成功操作过？`,
      nextOnCondition: [
        { condition: '用户描述借书异常', nextStep: 'step-02a' },
        { condition: '用户描述还书异常', nextStep: 'step-02b' },
        { condition: '用户描述续借异常', nextStep: 'step-02c' },
        { condition: '用户描述预约异常', nextStep: 'step-02d' },
        { condition: '用户描述罚款/费用异常', nextStep: 'step-02e' },
        { condition: '用户描述账户异常', nextStep: 'step-02f' },
      ],
      fallbackStep: 'step-02a',
    },
    {
      id: 'step-02a',
      name: '借阅异常诊断',
      type: 'analysis',
      prompt: `分析借阅异常可能原因：
- 检查在借册数是否已达上限
- 检查读者证状态是否正常
- 检查图书是否可借（非保留本/不外借）
- 检查是否有逾期未还图书
- 检查是否有未缴罚款`,
      nextOnCondition: [
        { condition: '确认为册数超限', nextStep: 'step-03a' },
        { condition: '确认为读者证异常', nextStep: 'step-03b' },
        { condition: '确认为图书不可借', nextStep: 'step-03c' },
        { condition: '无法自诊断', nextStep: 'step-escalate' },
      ],
      fallbackStep: 'step-escalate',
    },
    {
      id: 'step-02b',
      name: '归还异常诊断',
      type: 'analysis',
      prompt: `分析归还异常可能原因：
- 检查图书是否逾期
- 检查图书是否属于本馆
- 检查图书条码/RFID是否损坏
- 检查自助设备是否正常`,
      nextOnCondition: [
        { condition: '确认为逾期问题', nextStep: 'step-03d' },
        { condition: '确认为条码/设备问题', nextStep: 'step-03e' },
        { condition: '确认为非本馆图书', nextStep: 'step-escalate' },
        { condition: '无法自诊断', nextStep: 'step-escalate' },
      ],
      fallbackStep: 'step-escalate',
    },
    {
      id: 'step-02c',
      name: '续借异常诊断',
      type: 'analysis',
      prompt: `分析续借异常可能原因：
- 检查是否已达最大续借次数
- 检查图书是否被他人预约
- 检查读者证是否正常
- 检查是否有逾期图书`,
      nextOnCondition: [
        { condition: '确认为续借次数上限', nextStep: 'step-03f' },
        { condition: '确认为被预约', nextStep: 'step-03g' },
        { condition: '无法自诊断', nextStep: 'step-escalate' },
      ],
      fallbackStep: 'step-escalate',
    },
    {
      id: 'step-02d',
      name: '预约异常诊断',
      type: 'analysis',
      prompt: `分析预约异常可能原因：
- 检查当前是否已有该书在借
- 检查预约队列状态
- 检查读者证是否正常`,
      nextOnCondition: [
        { condition: '确认为已有在借', nextStep: 'step-03h' },
        { condition: '无法自诊断', nextStep: 'step-escalate' },
      ],
      fallbackStep: 'step-escalate',
    },
    {
      id: 'step-02e',
      name: '罚款异常诊断',
      type: 'analysis',
      prompt: `分析罚款相关问题：
- 说明罚款计算规则（每册每天0.1元）
- 检查是否有多种罚款叠加
- 提供缴费方式和减免政策`,
      nextOnCondition: [
        { condition: '用户接受解释', nextStep: 'step-03i' },
        { condition: '用户有异议', nextStep: 'step-escalate' },
      ],
      fallbackStep: 'step-escalate',
    },
    {
      id: 'step-02f',
      name: '账户异常诊断',
      type: 'analysis',
      prompt: `分析账户异常可能原因：
- 检查统一认证状态
- 检查新生数据同步
- 检查密码锁定状态
- 提供解锁渠道`,
      nextOnCondition: [
        { condition: '确认为密码问题', nextStep: 'step-03j' },
        { condition: '确认为数据同步问题', nextStep: 'step-03k' },
        { condition: '需要人工处理', nextStep: 'step-escalate' },
      ],
      fallbackStep: 'step-escalate',
    },
    {
      id: 'step-03a',
      name: '册数超限解决方案',
      type: 'solution',
      prompt: `【解决方案】借阅册数超限：
1. 归还部分在借图书后再借新书
2. 本科生最多借阅20册，研究生30册，教师40册
3. 可在"我的借阅"查看当前借阅列表
4. 如有逾期图书，需先归还并缴清罚款`,
      nextOnCondition: [{ condition: '完成', nextStep: 'step-confirm' }],
    },
    {
      id: 'step-03b',
      name: '读者证异常解决方案',
      type: 'escalation',
      prompt: `【需要人工处理】读者证状态异常：
此问题需要前往图书馆服务台处理。
请携带校园卡前往一层服务台，工作人员将协助您：
1. 核查读者证状态
2. 处理冻结/挂失/过期等问题
3. 恢复借阅权限`,
      nextOnCondition: [{ condition: '完成', nextStep: 'step-confirm' }],
    },
    {
      id: 'step-03c',
      name: '图书不可借解决方案',
      type: 'solution',
      prompt: `【解决方案】图书不可借：
1. 保留本/库本仅限馆内阅览，请在馆内使用
2. 查询是否有其他复本可借
3. 工具书通常在工具书阅览区，不提供外借
4. 可尝试通过馆际互借获取`,
      nextOnCondition: [{ condition: '完成', nextStep: 'step-confirm' }],
    },
    {
      id: 'step-03d',
      name: '逾期处理方案',
      type: 'solution',
      prompt: `【解决方案】图书逾期处理：
1. 请尽快归还逾期图书
2. 每册每天产生0.1元逾期费
3. 可通过以下方式缴纳：
   - 图书馆自助缴费机（校园卡支付）
   - 线上缴费平台
4. 如有特殊情况可申请减免`,
      nextOnCondition: [{ condition: '完成', nextStep: 'step-confirm' }],
    },
    {
      id: 'step-03e',
      name: '设备问题方案',
      type: 'solution',
      prompt: `【解决方案】设备/条码问题：
1. 尝试更换另一台自助借还机
2. 调整扫描距离和角度重试
3. 如条码明显损坏，请前往服务台人工处理
4. 如多台设备均异常，可能是系统问题，请稍后再试`,
      nextOnCondition: [{ condition: '完成', nextStep: 'step-confirm' }],
    },
    {
      id: 'step-escalate',
      name: '升级到人工服务',
      type: 'escalation',
      prompt: `【升级处理】此问题需要人工介入：
📍 请前往一层图书馆服务台
⏰ 服务时间：工作日 8:30-17:30，周末 9:00-17:00
📞 咨询电话：图书馆服务台
💡 请准备好您的校园卡和相关图书信息`,
      nextOnCondition: [{ condition: '完成', nextStep: 'step-confirm' }],
    },
    {
      id: 'step-confirm',
      name: '确认解决',
      type: 'confirmation',
      prompt: `请问以上信息是否解决了您的问题？如果还有疑问，请告诉我具体细节，我会进一步协助您。`,
    },
  ],
};