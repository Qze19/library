/**
 * 工作流二：馆务辅助与分类整理工作流
 * 处理馆务管理相关需求，包括图书分类咨询、索书号解读、采购建议等
 */
 
export interface ManagementWorkflowStep {
  id: string;
  name: string;
  type: 'classification' | 'call_number' | 'recommendation' | 'statistics' | 'cataloging' | 'confirmation';
  prompt: string;
}
 
export interface ManagementWorkflow {
  id: string;
  name: string;
  description: string;
  triggerIntents: string[];
  steps: ManagementWorkflowStep[];
}
 
export const LIBRARY_MANAGEMENT_WORKFLOW: ManagementWorkflow = {
  id: 'wf-library-management',
  name: '馆务辅助与分类整理工作流',
  description: '提供图书分类咨询、索书号解读、新书采购建议、馆藏分析等馆务管理辅助功能',
  triggerIntents: ['library_management'],
  steps: [
    {
      id: 'step-m01',
      name: '需求识别',
      type: 'classification',
      prompt: `请告诉我您需要哪方面的馆务帮助：
1. 📖 图书分类咨询 — 了解某本书的分类号或某类图书的位置
2. 🔢 索书号解读 — 理解索书号的组成和排架规则
3. 📚 新书推荐/采购建议 — 推荐值得采购的新书
4. 📊 馆藏统计查询 — 了解馆藏分布和统计信息
5. 🏷️ 编目规则咨询 — 了解编目和分类规范`,
    },
    {
      id: 'step-m02',
      name: '分类咨询处理',
      type: 'classification',
      prompt: `根据中图法分类体系为您提供图书分类信息：
- 提供对应的分类号和类名
- 说明在馆内的具体位置（楼层和区域）
- 介绍相关分类下的重要馆藏资源`,
    },
    {
      id: 'step-m03',
      name: '索书号解读',
      type: 'call_number',
      prompt: `索书号解读规则：
- 索书号 = 分类号 + 种次号（如 TP391.13/123）
- 分类号由字母和数字组成，表示图书学科
- 种次号为该分类下的入藏序号
- 排架时按分类号字母顺序 + 数字大小排列`,
    },
    {
      id: 'step-m04',
      name: '采购建议处理',
      type: 'recommendation',
      prompt: `新书采购建议处理流程：
1. 确认推荐图书的基本信息（书名、作者、出版社、ISBN）
2. 检查是否已有馆藏或电子版
3. 评估与学科建设的相关性
4. 提交采购建议至采访编目部
5. 反馈预计采购周期（普通图书2-4周）`,
    },
    {
      id: 'step-m05',
      name: '馆藏统计查询',
      type: 'statistics',
      prompt: `馆藏统计查询规则：
- 按分类号统计各学科馆藏量
- 提供借阅热门排行
- 分析馆藏结构合理性
- 建议采购补缺方向`,
    },
    {
      id: 'step-m06',
      name: '确认完成',
      type: 'confirmation',
      prompt: `以上馆务信息是否满足您的需求？如有其他问题请随时提出。`,
    },
  ],
};