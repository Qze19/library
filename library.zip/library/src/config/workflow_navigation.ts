/**
 * 工作流三：空间与展馆导览工作流
 * 处理空间查询、座位预约、展览信息、楼层导航等需求
 */
 
export interface SpaceNavigationStep {
  id: string;
  name: string;
  type: 'space_query' | 'reservation' | 'navigation' | 'exhibition' | 'availability' | 'confirmation';
  prompt: string;
}
 
export interface SpaceNavigationWorkflow {
  id: string;
  name: string;
  description: string;
  triggerIntents: string[];
  steps: SpaceNavigationStep[];
}
 
export const SPACE_NAVIGATION_WORKFLOW: SpaceNavigationWorkflow = {
  id: 'wf-space-navigation',
  name: '空间与展馆导览工作流',
  description: '提供图书馆空间查询、座位预约引导、楼层导航、展览活动查询等导览服务',
  triggerIntents: ['space_exhibition'],
  steps: [
    {
      id: 'step-s01',
      name: '空间需求识别',
      type: 'space_query',
      prompt: `请问您需要哪种空间服务：
1. 🪑 自习座位 — 查找可用的自习座位
2. 💬 研讨间预约 — 小组讨论或会议空间
3. 🖥️ 多媒体空间 — 电脑/专业设备使用
4. 🎨 展览活动 — 查看当前展览或活动
5. 🗺️ 楼层导航 — 了解各楼层功能分布
6. ⏰ 开放时间 — 查询各区域开放时间`,
    },
    {
      id: 'step-s02',
      name: '自习座位查询',
      type: 'availability',
      prompt: `自习座位查询服务：
- 提供各楼层自习区实时座位状态
- 引导用户完成座位预约流程
- 说明预约规则和使用时长
- 提供24小时学习区的进入方式`,
    },
    {
      id: 'step-s03',
      name: '研讨间预约引导',
      type: 'reservation',
      prompt: `研讨间预约流程：
1. 选择研讨间类型：
   - 小型（3-8人）：五层东区1-8号，提前24小时预约
   - 大型（8-20人）：五层西区9-10号，提前48小时预约
2. 在线填写预约申请（人数、时间、用途）
3. 等待审批确认
4. 按时使用，使用后恢复原状`,
    },
    {
      id: 'step-s04',
      name: '空间设施查询',
      type: 'space_query',
      prompt: `空间设施详情：
根据您选择的空间类型，提供以下信息：
- 具体位置（楼层、区域）
- 容量和使用规则
- 配套设施（电源、网络、投影等）
- 开放时间和预约要求`,
    },
    {
      id: 'step-s05',
      name: '展览活动查询',
      type: 'exhibition',
      prompt: `展览活动查询服务：
- 一层展览厅当前展览主题和时间
- 报告厅近期活动安排
- 展览参观须知
- 活动预约和报名方式`,
    },
    {
      id: 'step-s06',
      name: '楼层导航',
      type: 'navigation',
      prompt: `楼层导航指引：
一层：报告厅 · 展览厅 · 朗读亭 · 24小时自助学习区 · 服务台
二层：综合阅览区 · 咖啡书吧 · 新书展区 · 自助借还区
三层：报刊阅览室 · 多媒体学习空间 · 电子阅览区
四层：自习室A/B区 · 图书借阅区（A-K类）
五层：研讨间（1-10号） · 特藏阅览室 · 图书借阅区（N-Z类）
六层：创客空间 · 图书馆办公区`,
    },
    {
      id: 'step-s07',
      name: '确认完成',
      type: 'confirmation',
      prompt: `以上空间导览信息是否满足您的需求？如需进一步帮助（如具体预约操作），请告诉我。`,
    },
  ],
};