/**
 * 平台 Data API 封装 — 智图灵伴
 * 统一数据访问层，直接请求平台公网地址
 */
 
const DATA_API_BASE =
  'https://edumaker.sslibweb.com/api/v2/projects/2233bb0fe38c40dcab1ff1f413f0cdd8/data';
 
async function platformDataApi(
  method: 'GET' | 'POST' | 'PATCH' | 'DELETE',
  table: string,
  options: {
    query?: Record<string, string | number | boolean>;
    body?: Record<string, unknown>;
    id?: string;
  } = {},
) {
  const suffix = options.id ? `/${options.id}` : '';
  const url = new URL(`${DATA_API_BASE}/${table}${suffix}`);
  if (options.query) {
    for (const [key, value] of Object.entries(options.query)) {
      url.searchParams.set(key, String(value));
    }
  }
 
  const response = await fetch(url, {
    method,
    headers: {
      Accept: 'application/json',
      ...(options.body ? { 'Content-Type': 'application/json' } : {}),
    },
    credentials: 'include',
    ...(options.body ? { body: JSON.stringify(options.body) } : {}),
  });
  if (!response.ok) throw new Error(await response.text());
  return response.json();
}
 
// ===== 配置表操作 =====
export async function getConfig(key: string) {
  const result = await platformDataApi('GET', 'agent_config', {
    query: { config_key: key, limit: 1, order: 'updated_at.desc' },
  });
  return result?.[0] ?? null;
}
 
export async function setConfig(key: string, value: unknown, description?: string) {
  return platformDataApi('POST', 'agent_config', {
    body: { config_key: key, config_value: value, description: description ?? '' },
  });
}
 
// ===== 对话记忆操作 =====
export async function saveConversationMemory(entry: {
  user_id: string;
  intent: string;
  query: string;
  response: string;
  knowledge_match_score: number;
  kb_source: string;
  fallback_used: boolean;
}) {
  return platformDataApi('POST', 'conversation_memory', { body: entry });
}
 
export async function getRecentMemories(userId: string, limit = 10) {
  return platformDataApi('GET', 'conversation_memory', {
    query: { user_id: userId, limit, order: 'created_at.desc' },
  });
}
 
// ===== 用户偏好操作 =====
export async function getUserPreferences(userId: string) {
  const result = await platformDataApi('GET', 'user_preferences', {
    query: { user_id: userId, limit: 1, order: 'updated_at.desc' },
  });
  return result?.[0] ?? null;
}
 
export async function saveUserPreferences(
  userId: string,
  preferences: Record<string, unknown>,
  tags: string[] = [],
) {
  const existing = await getUserPreferences(userId);
  if (existing) {
    return platformDataApi('PATCH', 'user_preferences', {
      id: existing.pref_id,
      body: { preferences, tags, updated_at: new Date().toISOString() },
    });
  }
  return platformDataApi('POST', 'user_preferences', {
    body: { user_id: userId, preferences, tags },
  });
}