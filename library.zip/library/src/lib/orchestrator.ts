/**
 * 智图灵伴 — 智能体编排器 v1.1
 * 核心路由引擎：意图识别 → 知识库匹配 → 工作流调度 → 兜底策略
 *
 * 新增：学术问询多阶段处理（意图拆分 → 馆藏匹配 → 联网补充 → 综合答复）
 */
 
import {
  SYSTEM_PROMPT,
  INTENT_KEYWORDS,
  INTENT_LABELS,
  INTENT_PRIORITY,
  type IntentType,
  type IntentMatch,
} from '../config/systemPrompt';
 
import { BORROWING_DIAGNOSTIC_KB } from '../config/knowledgeBase_diagnostics';
import { SPACE_KNOWLEDGE_BASE, FLOOR_MAP, TIME_RULES, NAV_QA_GUIDE } from '../config/knowledgeBase_spaces';
import { BOOK_CLASSIFICATION_KB, CALL_NUMBER_RULES } from '../config/knowledgeBase_classification';
import { MISSING_RESOURCES_KB, ELECTRONIC_RESOURCES_KB } from '../config/knowledgeBase_resources';
import {
  PHYSICAL_BOOKS_KB,
  EBOOKS_KB,
  PHYSICAL_EBOOK_MAP,
} from '../config/knowledgeBase_holdings';
 
import { BORROWING_DIAGNOSTIC_WORKFLOW } from '../config/workflow_diagnostic';
import { LIBRARY_MANAGEMENT_WORKFLOW } from '../config/workflow_management';
import { SPACE_NAVIGATION_WORKFLOW } from '../config/workflow_navigation';
import {
  ACADEMIC_INQUIRY_WORKFLOW,
  parseAcademicIntent,
  synthesizeAcademicResponse,
  type ParsedAcademicIntent,
  type HoldingsMatchItem,
  type WebSearchSupplement,
} from '../config/workflow_academic';
 
import { SKILL_CONFIGS } from '../config/skills';
import { executeWebSearch } from './webSearch';
import {
  saveConversationMemory,
} from './api';
 
// ===== 配置常量 =====
export const AGENT_CONFIG = {
  name: '智图灵伴',
  version: '1.1.0',
  knowledgeMatchThreshold: 0.85,
  maxRecentMemoryCount: 10,
  memoryRetentionDays: 180,
  enableLongTermMemory: true,
  enableWebSearch: true,
  enableFallback: true,
  holdingsKbName: '馆藏资源库',
};
 
// ===== 意图识别 =====
export function detectIntent(userMessage: string): IntentMatch | null {
  const normalized = userMessage.toLowerCase();
  const scored: { intent: IntentType; confidence: number; keywords: string[] }[] = [];
 
  for (const intent of INTENT_PRIORITY) {
    const keywords = INTENT_KEYWORDS[intent];
    const matched: string[] = [];
    let score = 0;
 
    for (const kw of keywords) {
      if (normalized.includes(kw.toLowerCase())) {
        matched.push(kw);
        score += kw.length >= 4 ? 0.3 : 0.15;
      }
    }
 
    if (matched.length > 0) {
      const confidence = Math.min(score / (keywords.length * 0.3) * 2, 1.0);
      scored.push({ intent, confidence, keywords: matched });
    }
  }
 
  scored.sort((a, b) => b.confidence - a.confidence);
 
  if (scored.length === 0) return null;
  return scored[0];
}
 
// ===== 知识库匹配 =====
export interface KnowledgeMatchResult {
  source: string;
  score: number;
  content: string;
  type: 'diagnostic' | 'space' | 'classification' | 'resource' | 'holdings';
  holdings?: HoldingsMatchItem[];
  webResults?: WebSearchSupplement[];
  parsedIntent?: ParsedAcademicIntent;
}
 
function simpleSimilarity(query: string, target: string): number {
  const qWords = new Set(query.toLowerCase().split(/[\s,，、。！？]+/));
  const tWords = new Set(target.toLowerCase().split(/[\s,，、。！？]+/));
 
  let overlap = 0;
  for (const w of qWords) {
    if (tWords.has(w) || [...tWords].some((tw) => tw.includes(w) || w.includes(tw))) {
      overlap++;
    }
  }
  return qWords.size > 0 ? overlap / qWords.size : 0;
}
 
// ===== 馆藏资源匹配（学术问询专用） =====
function matchHoldings(query: string, parsed: ParsedAcademicIntent): HoldingsMatchItem[] {
  const results: HoldingsMatchItem[] = [];
  const searchText = `${query} ${parsed.keywords.join(' ')} ${parsed.subjects.join(' ')}`.toLowerCase();
 
  // 匹配纸质书
  for (const pb of PHYSICAL_BOOKS_KB) {
    const allText = [
      pb.title,
      pb.author,
      ...pb.subjects,
      pb.callNumber,
      pb.classification,
      pb.description,
    ]
      .join(' ')
      .toLowerCase();
 
    const score = simpleSimilarity(searchText, allText);
    if (score > 0.1) {
      const statusText =
        pb.status === 'available'
          ? '✅ 可借'
          : pb.status === 'on_loan'
            ? '🔴 已借出'
            : pb.status === 'reading_only'
              ? '📖 仅供阅览'
              : '⏳ 处理中';
 
      results.push({
        type: 'physical',
        id: pb.id,
        title: pb.title,
        author: pb.author,
        detail: pb.description,
        location: `${pb.floor}${pb.zone} ${pb.shelf}`,
        callNumber: pb.callNumber,
        status: statusText,
        copies: `共${pb.totalCopies}册 / 可借${pb.availableCopies}册`,
        score,
      });
    }
  }
 
  // 匹配电子书
  for (const eb of EBOOKS_KB) {
    const allText = [eb.title, eb.author, ...eb.subjects, eb.description, eb.platform]
      .join(' ')
      .toLowerCase();
 
    const score = simpleSimilarity(searchText, allText);
    if (score > 0.1) {
      results.push({
        type: 'ebook',
        id: eb.id,
        title: eb.title,
        author: eb.author,
        detail: eb.description,
        url: eb.url,
        platform: eb.platform,
        accessMode: eb.accessMode === 'campus_ip'
          ? '🌐 校园IP访问'
          : eb.accessMode === 'open'
            ? '🆓 开放获取'
            : eb.accessMode === 'vpn'
              ? '🔒 VPN访问'
              : '👤 账号登录',
        score,
      });
    }
  }
 
  // 按分数降序排序
  results.sort((a, b) => b.score - a.score);
 
  // 去重：同书名只保留分数最高的
  const seen = new Set<string>();
  return results.filter((r) => {
    const key = r.title.toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}
 
// ===== 综合知识库匹配 =====
export function matchKnowledgeBase(
  query: string,
  intent: IntentType | 'academic_inquiry',
): KnowledgeMatchResult | null {
  let bestScore = 0;
  let bestResult: KnowledgeMatchResult | null = null;
 
  // 学术问询 — 走馆藏资源匹配 + 联网搜索
  if (intent === 'academic_inquiry') {
    const parsed = parseAcademicIntent(query);
 
    // 阶段二：馆藏匹配
    const holdings = matchHoldings(query, parsed);
    const maxHoldingScore = holdings.length > 0 ? Math.max(...holdings.map((h) => h.score)) : 0;
 
    // 阶段三：联网补充（异步在 orchestrate 中完成）
    // 这里先标记需要联网搜索的主题
    const existingTitles = holdings.map((h) => h.title);
    const needSearchTopics = parsed.keywords.filter(
      (kw) => !existingTitles.some((t) => t.toLowerCase().includes(kw.toLowerCase())),
    );
 
    if (holdings.length > 0) {
      const physicalCount = holdings.filter((h) => h.type === 'physical').length;
      const ebookCount = holdings.filter((h) => h.type === 'ebook').length;
 
      bestScore = Math.max(maxHoldingScore, 0.5);
      bestResult = {
        source: AGENT_CONFIG.holdingsKbName,
        score: bestScore,
        content: '',
        type: 'holdings',
        holdings,
        parsedIntent: parsed,
      };
    } else {
      // 馆藏无匹配，低分进入联网搜索
      bestScore = 0.2;
      bestResult = {
        source: '联网搜索',
        score: 0.2,
        content: '',
        type: 'holdings',
        holdings: [],
        parsedIntent: parsed,
      };
    }
    return bestResult;
  }
 
  // 借阅异常（原有逻辑）
  if (intent === 'borrowing_exception') {
    for (const entry of BORROWING_DIAGNOSTIC_KB) {
      const allText = [entry.symptom, ...entry.symptoms, ...entry.tags].join(' ');
      const score = simpleSimilarity(query, allText);
      if (score > bestScore) {
        bestScore = score;
        bestResult = {
          source: '借阅异常诊断库',
          score,
          content: `【${entry.symptom}】\n可能原因：${entry.possibleCauses.join('；')}\n解决方案：${entry.solutions.join('；')}`,
          type: 'diagnostic',
        };
      }
    }
  }
 
  if (intent === 'space_exhibition') {
    // 先匹配高频导航问答（如"新书在哪""从哪个门进"）
    let bestQA: { answer: string; matched: number } | null = null;
    for (const qa of NAV_QA_GUIDE) {
      const matched = qa.keywords.filter((kw) => query.includes(kw)).length;
      if (matched > 0 && (!bestQA || matched > bestQA.matched)) {
        bestQA = { answer: `【${qa.question}】\n${qa.answer}`, matched };
      }
    }
    if (bestQA) {
      return {
        source: '馆内导航指引',
        score: 0.95,
        content: bestQA.answer,
        type: 'space',
      };
    }

    for (const space of SPACE_KNOWLEDGE_BASE) {
      const allText = [space.name, space.description, ...space.facilities, ...space.rules, space.category].join(' ');
      const score = simpleSimilarity(query, allText);
      if (score > bestScore) {
        bestScore = score;
        const lines = [
          `【${space.name}】${space.description}`,
          `📍 位置：${space.floor}层 ${space.zone}${space.position ? `（${space.position}）` : ''}`,
          `开放时间：${space.openTime}-${space.closeTime}`,
        ];
        if (space.capacity > 0) lines.push(`容量：${space.capacity}人`);
        if (space.facilities.length > 0) lines.push(`设施：${space.facilities.join('、')}`);
        if (space.rules.length > 0) lines.push(`规则：${space.rules.join('；')}`);
        bestResult = {
          source: '空间与导航库',
          score,
          content: lines.join('\n'),
          type: 'space',
        };
      }
    }
    for (const [floor, info] of Object.entries(FLOOR_MAP)) {
      const score = simpleSimilarity(query, info);
      if (score > bestScore) {
        bestScore = score;
        bestResult = {
          source: '空间与导航库',
          score,
          content: info,
          type: 'space',
        };
      }
    }
  }
 
  if (intent === 'library_management') {
    for (const entry of BOOK_CLASSIFICATION_KB) {
      const allText = [entry.code, entry.className, entry.description, ...entry.keywords].join(' ');
      const score = simpleSimilarity(query, allText);
      if (score > bestScore) {
        bestScore = score;
        const subInfo = entry.subClasses.map((s) => `${s.code} ${s.name}`).join('；');
        bestResult = {
          source: '图书分类索引库',
          score,
          content: `【${entry.code}】${entry.className}\n${entry.description}\n位置：${entry.location}\n子类：${subInfo}`,
          type: 'classification',
        };
      }
    }
  }
 
  // 通用资源匹配
  for (const res of MISSING_RESOURCES_KB) {
    const allText = [res.title, res.author ?? '', res.status, res.notes].join(' ');
    const score = simpleSimilarity(query, allText);
    if (score > bestScore) {
      bestScore = score;
      bestResult = {
        source: '资源缺失/目录库',
        score,
        content: `【${res.title}】${res.status}\n替代获取：${res.alternativeAccess ?? '暂无可替代资源'}`,
        type: 'resource',
      };
    }
  }
 
  for (const er of ELECTRONIC_RESOURCES_KB) {
    const allText = [er.name, er.description, ...er.subjects].join(' ');
    const score = simpleSimilarity(query, allText);
    if (score > bestScore) {
      bestScore = score;
      bestResult = {
        source: '资源缺失/目录库',
        score,
        content: `【${er.name}】${er.description}\n访问方式：${er.accessMode}\n学科：${er.subjects.join('、')}`,
        type: 'resource',
      };
    }
  }
 
  return bestResult;
}
 
// ===== 输出格式组装 =====
export function formatResponse(
  intent: IntentType | 'academic_inquiry' | 'unknown',
  kbResult: KnowledgeMatchResult | null,
  query: string,
): string {
  const label = intent !== 'unknown' ? INTENT_LABELS[intent] ?? '🎓 学术问询' : '📖 通用咨询';
  let response = `【智图灵伴】您好！\n\n📋 **问题识别**：${label}\n\n`;
 
  if (kbResult && kbResult.score >= AGENT_CONFIG.knowledgeMatchThreshold) {
    response += `${kbResult.content}\n\n`;
    response += `🔍 **知识来源**：${kbResult.source}（匹配度：${(kbResult.score * 100).toFixed(1)}%）`;
  } else if (kbResult) {
    response += `基于部分匹配信息（${(kbResult.score * 100).toFixed(1)}%），为您提供以下参考：\n\n${kbResult.content}\n\n`;
    response += `⚠️ 匹配度低于阈值（${AGENT_CONFIG.knowledgeMatchThreshold * 100}%），信息仅供参考。`;
  }
 
  if (!kbResult || kbResult.score < AGENT_CONFIG.knowledgeMatchThreshold) {
    response += `\n\n💡 **相关提示**：建议您尝试换个方式描述问题，或前往图书馆服务台获取更确切的帮助。`;
  }
 
  response += `\n\n📞 **进一步帮助**：如需人工服务，请联系图书馆服务台。`;
  return response;
}
 
// ===== 兜底回复 =====
export function getFallbackResponse(): string {
  return `【智图灵伴】抱歉，我暂时无法准确回答您的问题。
 
🔍 我已记录了您的问题，建议您：
1. 尝试换个方式重新描述您的问题
2. 前往图书馆服务台咨询人工馆员
3. 通过图书馆官网的"读者留言"提交详细问题
 
我会持续学习，努力为您提供更好的服务！`;
}
 
// ===== 主编排流程 =====
export interface AgentResponse {
  message: string;
  intent: IntentType | 'academic_inquiry' | 'unknown';
  kbMatch: KnowledgeMatchResult | null;
  kbScore: number;
  fallbackUsed: boolean;
  workflowTriggered: string | null;
  skillsUsed: string[];
  webSearchUsed: boolean;
}
 
export async function orchestrate(
  userMessage: string,
  userId: string = 'anonymous',
): Promise<AgentResponse> {
  const skillsUsed: string[] = [];
  let webSearchUsed = false;
 
  // 1. 意图识别
  const intentMatch = detectIntent(userMessage);
  const intent: IntentType | 'academic_inquiry' | 'unknown' =
    intentMatch?.intent ?? 'unknown';
 
  // 2. 知识库匹配
  const kbResult =
    intent !== 'unknown' ? matchKnowledgeBase(userMessage, intent) : null;
 
  const kbScore = kbResult?.score ?? 0;
  const aboveThreshold = kbScore >= AGENT_CONFIG.knowledgeMatchThreshold;
 
  // 3. 工作流触发
  let workflowTriggered: string | null = null;
 
  // 学术问询：完整四阶段工作流
  if (intent === 'academic_inquiry' && kbResult?.parsedIntent) {
    workflowTriggered = ACADEMIC_INQUIRY_WORKFLOW.name;
    skillsUsed.push('资源推荐（按标签）');
 
    // 阶段三：联网补充
    if (AGENT_CONFIG.enableWebSearch) {
      const parsed = kbResult.parsedIntent;
      const existingTitles = (kbResult.holdings ?? []).map((h) => h.title);
      const needSearchTopics = parsed.keywords.filter(
        (kw) =>
          !existingTitles.some((t) =>
            t.toLowerCase().includes(kw.toLowerCase()) ||
            kw.toLowerCase().includes(t.toLowerCase()),
          ),
      );
 
      if (needSearchTopics.length > 0 && parsed.subjects.length > 0) {
        try {
          const webResults = await executeWebSearch(
            [...parsed.subjects, ...needSearchTopics],
            existingTitles,
          );
          if (webResults.length > 0) {
            kbResult.webResults = webResults;
            webSearchUsed = true;
            skillsUsed.push('联网搜索');
          }
        } catch {
          // 联网搜索失败不阻断主流程
        }
      }
    }
 
    // 阶段四：综合答复
    const message = synthesizeAcademicResponse(
      kbResult.parsedIntent,
      kbResult.holdings ?? [],
      kbResult.webResults ?? [],
    );
 
    // 长期记忆
    if (AGENT_CONFIG.enableLongTermMemory && userId !== 'anonymous') {
      try {
        await saveConversationMemory({
          user_id: userId,
          intent,
          query: userMessage,
          response: message,
          knowledge_match_score: Math.round(kbScore * 100),
          kb_source: kbResult?.source ?? 'none',
          fallback_used: false,
        });
      } catch {
        // 静默失败
      }
    }
 
    return {
      message,
      intent,
      kbMatch: kbResult,
      kbScore,
      fallbackUsed: false,
      workflowTriggered,
      skillsUsed,
      webSearchUsed,
    };
  }
 
  // 非学术意图沿用原有工作流触发逻辑
  if (intent === 'borrowing_exception' && aboveThreshold) {
    workflowTriggered = BORROWING_DIAGNOSTIC_WORKFLOW.name;
  } else if (intent === 'library_management') {
    workflowTriggered = LIBRARY_MANAGEMENT_WORKFLOW.name;
  } else if (intent === 'space_exhibition') {
    workflowTriggered = SPACE_NAVIGATION_WORKFLOW.name;
  }
 
  // 4. 技能使用
  if (intent === 'reader_service') {
    skillsUsed.push('文献传递');
  }
  if (aboveThreshold) {
    skillsUsed.push('资源推荐（按标签）');
  }
  if (!aboveThreshold && AGENT_CONFIG.enableWebSearch) {
    skillsUsed.push('联网搜索');
  }
 
  // 5. 生成回复
  const fallbackUsed = !aboveThreshold && kbScore < 0.3;
  const message = fallbackUsed
    ? getFallbackResponse()
    : formatResponse(intent, kbResult, userMessage);
 
  // 6. 长期记忆
  if (AGENT_CONFIG.enableLongTermMemory && userId !== 'anonymous') {
    try {
      await saveConversationMemory({
        user_id: userId,
        intent,
        query: userMessage,
        response: message,
        knowledge_match_score: Math.round(kbScore * 100),
        kb_source: kbResult?.source ?? 'none',
        fallback_used: fallbackUsed,
      });
    } catch {
      // 静默失败，不影响主流程
    }
  }
 
  return {
    message,
    intent,
    kbMatch: kbResult,
    kbScore,
    fallbackUsed,
    workflowTriggered,
    skillsUsed,
    webSearchUsed,
  };
}
 
// ===== 系统状态查询 =====
export function getAgentStatus() {
  return {
    name: AGENT_CONFIG.name,
    version: AGENT_CONFIG.version,
    knowledgeMatchThreshold: AGENT_CONFIG.knowledgeMatchThreshold,
    enableLongTermMemory: AGENT_CONFIG.enableLongTermMemory,
    enableWebSearch: AGENT_CONFIG.enableWebSearch,
    skills: SKILL_CONFIGS.map((s) => ({ id: s.id, name: s.name, enabled: s.enabled })),
    knowledgeBases: [
      { name: '空间与导航库', entries: SPACE_KNOWLEDGE_BASE.length + NAV_QA_GUIDE.length },
      { name: '借阅异常诊断库', entries: BORROWING_DIAGNOSTIC_KB.length },
      { name: '图书分类索引库', entries: BOOK_CLASSIFICATION_KB.length },
      { name: '资源缺失/目录库', entries: MISSING_RESOURCES_KB.length + ELECTRONIC_RESOURCES_KB.length },
      { name: '馆藏资源库', entries: PHYSICAL_BOOKS_KB.length + EBOOKS_KB.length },
    ],
    workflows: [
      BORROWING_DIAGNOSTIC_WORKFLOW.name,
      LIBRARY_MANAGEMENT_WORKFLOW.name,
      SPACE_NAVIGATION_WORKFLOW.name,
      ACADEMIC_INQUIRY_WORKFLOW.name,
    ],
  };
}