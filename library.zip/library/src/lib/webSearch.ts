/**
 * 联网搜索工具
 * 使用 web_search 能力对本地知识库缺失的信息进行补充检索
 * 此模块只能在编排器端（Node/Agent 环境）调用，不经过浏览器。
 *
 * 浏览器运行时使用 fetch 对公开 API 的替代路径（见下方 browserFallbackSearch）。
 */
 
export interface WebSearchResult {
  title: string;
  author: string;
  summary: string;
  sourceUrl: string;
  relevance: string;
  searched: boolean;
}
 
/**
 * 模拟联网搜索 — 在实际部署环境中替换为真实 API 调用
 * 当前根据预置的书籍信息库返回"联网搜索结果"
 *
 * 结构保持与真实搜索一致，后续替换 web_search 工具即可。
 */
const KNOWN_BOOK_DETAILS: Record<string, WebSearchResult> = {
  '深度学习': {
    title: '深度学习（Deep Learning）',
    author: 'Ian Goodfellow, Yoshua Bengio, Aaron Courville',
    summary:
      '全书分三部分：第1部分介绍数学基础（线性代数、概率论、数值计算）；第2部分讲解现代深度网络（深度前馈网络、正则化、卷积网络、序列模型）；第3部分覆盖深度学习研究前沿（线性因子模型、自编码器、表示学习、蒙特卡洛方法等）。被誉为"AI圣经"。',
    sourceUrl: 'https://www.deeplearningbook.org',
    relevance: '人工智能方向核心教材，适合研究生和科研人员系统学习深度学习理论。',
    searched: true,
  },
  '机器学习': {
    title: '机器学习（西瓜书）',
    author: '周志华',
    summary:
      '涵盖机器学习基础、模型评估与选择、线性模型、决策树、神经网络、支持向量机、贝叶斯分类器、集成学习、聚类、降维与度量学习、特征选择、计算学习理论、半监督学习、概率图模型、规则学习、强化学习等16章。每章附习题，适合自学和教学。',
    sourceUrl: 'https://cs.nju.edu.cn/zhouzh/zhouzh.files/publication/MLbook2016.htm',
    relevance: '中文机器学习入门首选教材，理论与算法并重。',
    searched: true,
  },
  '统计学习': {
    title: '统计学习方法（第2版）',
    author: '李航',
    summary:
      '第2版新增深度学习、无监督学习等内容。系统介绍感知机、k近邻、朴素贝叶斯、决策树、逻辑回归、支持向量机、提升方法、EM算法、隐马尔可夫模型、条件随机场等10种经典统计学习方法，并附完整数学推导。',
    sourceUrl: 'https://book.douban.com/subject/33437381/',
    relevance: '国内统计学习领域最权威的中文教材，适合需要深入理解算法原理的读者。',
    searched: true,
  },
  '算法导论': {
    title: '算法导论（CLRS）原书第3版',
    author: 'Thomas H. Cormen, Charles E. Leiserson, Ronald L. Rivest, Clifford Stein',
    summary:
      '全书共八部分35章：基础（算法角色、渐进记号）、排序与顺序统计量、数据结构（栈/队列/树/堆/图）、高级设计分析（动态规划/贪心/摊还分析）、高级数据结构（B树/斐波那契堆）、图算法（最小生成树/最短路径/最大流）、NP完全性、近似算法。MIT经典教材。',
    sourceUrl: 'https://mitpress.mit.edu/books/introduction-algorithms-third-edition',
    relevance: '全球计算机科学专业标准教材，算法方向必读，适合系统学习与面试准备。',
    searched: true,
  },
  '计算机网络': {
    title: '计算机网络：自顶向下方法（第7版）',
    author: 'James F. Kurose, Keith W. Ross',
    summary:
      '以自顶向下方式组织：应用层（HTTP/DNS/P2P）、传输层（TCP/UDP）、网络层（IP/路由）、链路层（以太网/WiFi）、无线网络、网络安全。每章附有编程作业和Wireshark实验，理论与实践结合紧密。',
    sourceUrl: 'https://gaia.cs.umass.edu/kurose_ross/',
    relevance: '计算机网络方向最受欢迎教材，语言生动，案例丰富。',
    searched: true,
  },
  '编译原理': {
    title: '编译原理（龙书）第2版',
    author: 'Alfred V. Aho, Monica S. Lam, Ravi Sethi, Jeffrey D. Ullman',
    summary:
      '全面覆盖编译器设计：词法分析、语法分析（LL/LR）、语法制导翻译、中间代码生成、代码优化、运行时环境、目标代码生成。第2版新增面向对象语言编译、垃圾回收、指令级并行等现代主题。',
    sourceUrl: 'https://www.pearson.com/en-us/subject-catalog/p/compilers-principles-techniques-and-tools/P200000003355',
    relevance: '编译器领域最权威教材，适合深入学习程序设计语言实现。',
    searched: true,
  },
  '经济学原理': {
    title: '经济学原理（第8版）',
    author: 'N. Gregory Mankiw',
    summary:
      '微观经济学分册涵盖：经济学十大原理、供求与市场均衡、弹性、消费者/生产者理论、市场效率、公共部门经济学、企业行为、市场结构（竞争/垄断/寡头）、要素市场、收入分配、微观经济学前沿。语言生动，案例贴近现实。',
    sourceUrl: 'https://www.cengage.com/c/principles-of-economics-8e-mankiw',
    relevance: '全球最畅销的经济学入门教材，适合非经济学专业学生培养经济思维。',
    searched: true,
  },
  '社会心理学': {
    title: '社会心理学（第11版）',
    author: 'David G. Myers',
    summary:
      '系统覆盖社会思维（自我概念、社会信念、态度与行为）、社会影响（从众、说服、群体影响）、社会关系（偏见、攻击、吸引与亲密、利他与冲突）。以丰富的实验研究和真实案例揭示社会行为规律。',
    sourceUrl: 'https://www.macmillanlearning.com/college/us/product/Social-Psychology/p/131919178X',
    relevance: '社会心理学领域最受欢迎的入门教材，适合心理学和社会科学方向学生。',
    searched: true,
  },
  '线性代数': {
    title: '线性代数及其应用（第5版）',
    author: 'David C. Lay, Steven R. Lay, Judi J. McDonald',
    summary:
      '从线性方程组出发，系统讲解矩阵运算、行列式、向量空间、特征值与特征向量、正交性与最小二乘法、对称矩阵与二次型。强调几何直观和实际应用，每章包含大量应用案例。',
    sourceUrl: 'https://www.pearson.com/en-us/subject-catalog/p/linear-algebra-and-its-applications/P200000006196',
    relevance: '工科线性代数首选教材，理论与应用并重，适合计算机/电子/机械等方向。',
    searched: true,
  },
  '操作系统': {
    title: '操作系统概念（恐龙书）第9版',
    author: 'Abraham Silberschatz, Peter B. Galvin, Greg Gagne',
    summary:
      '覆盖进程管理、线程与并发、CPU调度、同步与死锁、内存管理（分页/分段）、虚拟内存、文件系统、I/O系统、安全与保护。第9版新增多核系统、移动操作系统等现代主题。配套编程项目强化实践。',
    sourceUrl: 'https://www.wiley.com/en-us/Operating+System+Concepts%2C+9th+Edition-p-9781118063330',
    relevance: '操作系统方向最经典教材，全球数百所大学选用。',
    searched: true,
  },
  '数据库': {
    title: '数据库系统概念（第7版）',
    author: 'Abraham Silberschatz, Henry F. Korth, S. Sudarshan',
    summary:
      '涵盖关系模型、SQL、中级/高级SQL、E-R模型、关系数据库设计、存储与文件结构、索引与散列、查询处理与优化、事务管理、并发控制、恢复系统、并行数据库、分布式数据库、大数据与NoSQL。',
    sourceUrl: 'https://www.db-book.com',
    relevance: '数据库领域标准教材，理论与系统实现并重。',
    searched: true,
  },
  'Python': {
    title: 'Python编程：从入门到实践（第3版）',
    author: 'Eric Matthes',
    summary:
      '分两部分：第1部分Python基础（变量、列表、字典、if/while/函数、类、文件与异常、测试）；第2部分项目实战（外星人入侵游戏、数据可视化、Web应用Django）。以项目驱动方式循序渐进。',
    sourceUrl: 'https://nostarch.com/python-crash-course-3rd-edition',
    relevance: '全球最畅销的Python入门书，适合零基础读者快速上手。',
    searched: true,
  },
  'C++': {
    title: 'C++ Primer（第5版）中文版',
    author: 'Stanley B. Lippman, Josée Lajoie, Barbara E. Moo',
    summary:
      '全面覆盖C++11标准：变量和基本类型、字符串/向量/数组、表达式、语句、函数、类、IO库、顺序容器、泛型算法、关联容器、动态内存、拷贝控制、重载运算与类型转换、面向对象编程、模板与泛型编程、标准库特殊设施。',
    sourceUrl: 'https://www.informit.com/store/c-plus-plus-primer-9780321714114',
    relevance: 'C++方向最权威的入门和进阶教材，适合系统学习现代C++编程。',
    searched: true,
  },
  'JavaScript': {
    title: 'JavaScript高级程序设计（第4版）',
    author: 'Matt Frisbie',
    summary:
      '涵盖JS语言核心（变量/作用域/引用类型/集合/迭代器/生成器/对象/类/代理/函数/Promise/异步）、BOM/DOM/事件/表单/JSON/Ajax/WebSocket/Storage/Canvas/Web Workers/Service Worker。全面覆盖ES6+新特性。',
    sourceUrl: 'https://www.wiley.com/en-us/Professional+JavaScript+for+Web+Developers%2C+4th+Edition-p-9781119366447',
    relevance: '前端开发必读"红宝书"，适合系统学习JavaScript全貌。',
    searched: true,
  },
  '软件工程': {
    title: '设计模式：可复用面向对象软件的基础',
    author: 'Erich Gamma, Richard Helm, Ralph Johnson, John Vlissides',
    summary:
      'GoF经典之作，系统归纳23种设计模式：创建型（工厂/抽象工厂/单例/建造者/原型）、结构型（适配器/桥接/组合/装饰/外观/享元/代理）、行为型（责任链/命令/解释器/迭代器/中介者/备忘录/观察者/状态/策略/模板方法/访问者）。',
    sourceUrl: 'https://www.pearson.com/en-us/subject-catalog/p/design-patterns-elements-of-reusable-object-oriented-software/P200000009460',
    relevance: '面向对象设计的奠基之作，软件工程师必读。',
    searched: true,
  },
};
 
/**
 * 执行联网搜索 — 根据主题关键词检索书籍详细信息
 * @param topics 搜索主题关键词
 * @param existingTitles 已有馆藏信息的书名（避免重复搜索）
 * @returns 联网搜索补充结果
 */
export async function executeWebSearch(
  topics: string[],
  existingTitles: string[],
): Promise<WebSearchResult[]> {
  const results: WebSearchResult[] = [];
  const existingLower = existingTitles.map((t) => t.toLowerCase());
 
  for (const topic of topics) {
    // 跳过已有馆藏的
    if (existingLower.some((et) => et.includes(topic.toLowerCase()) || topic.toLowerCase().includes(et))) {
      continue;
    }
 
    // 在已知知识库中查找
    const found = KNOWN_BOOK_DETAILS[topic];
    if (found) {
      results.push(found);
    }
  }
 
  // 如果没有任何匹配结果，尝试模糊匹配
  if (results.length === 0) {
    for (const topic of topics) {
      for (const [key, value] of Object.entries(KNOWN_BOOK_DETAILS)) {
        if (
          key.toLowerCase().includes(topic.toLowerCase()) ||
          topic.toLowerCase().includes(key.toLowerCase())
        ) {
          if (!results.some((r) => r.title === value.title)) {
            results.push(value);
          }
        }
      }
    }
  }
 
  return results;
}
 
/**
 * 浏览器端联网搜索降级方案
 * 在无法调用真实搜索 API 时返回结构化提示
 */
export function browserSearchHint(topics: string[]): WebSearchResult[] {
  return topics.map((topic) => ({
    title: topic,
    author: '联网搜索',
    summary: `关于"${topic}"的详细信息需要通过联网搜索引擎获取。请确认网络连接后重试，或前往图书馆数据库自行检索。`,
    sourceUrl: `https://scholar.google.com/scholar?q=${encodeURIComponent(topic)}`,
    relevance: '建议通过知网、万方、Google Scholar等学术搜索引擎获取最新资料。',
    searched: false,
  }));
}